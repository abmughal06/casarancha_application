class ChatMessage {
  String? msgText;
  String time;
  String? separateTime;
  bool isSendByMe;

  ChatMessage({this.msgText, required this.time, required this.isSendByMe , this.separateTime});
}
