class ShareWithUser{
  bool isSelectShare = false , isVerify = false;
  String userName = "",subName = "", imgUrl = "";

  ShareWithUser(
      {required this.isSelectShare,
        required this.isVerify,
        required this.userName,
        required this.subName,
        required this.imgUrl});
}