class SuccessWithMsg {
  String? msgText;
  bool isSuccess;

  SuccessWithMsg({this.msgText, required this.isSuccess});
}
