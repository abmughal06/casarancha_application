class SignUpRequestModel {
  String? email;
  String? username;
  String? dob;
  String? password;
  String? deviceId;
  String? deviceType;
  String? otp;
  String? pushToken;

  SignUpRequestModel(
      {this.email, this.username, this.dob, this.password, this.otp, this.deviceId, this.deviceType, this.pushToken});

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['email'] = email;
    data['username'] = username;
    data['dob'] = dob;
    data['password'] = password;
    data['otp'] = otp;
    data['device_id'] = deviceId;
    data['device_type'] = deviceType;
    data['push_token'] = pushToken;
    return data;
  }
}

class SignupResponseModel {
  int? id;
  String? name;
  String? username;
  String? firstName;
  String? lastName;
  String? email;
  String? dob;
  String? profileCompleted;
  String? verified;
  String? bio;
  String? notification;
  String? profileImage;
  int? posts;
  int? following;
  int? followers;
  String? token;

  SignupResponseModel(
      {this.id,
      this.name,
      this.username,
      this.firstName,
      this.lastName,
      this.email,
      this.dob,
      this.profileCompleted,
      this.verified,
      this.bio,
      this.notification,
      this.profileImage,
      this.posts,
      this.following,
      this.followers,
      this.token});

  SignupResponseModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    username = json['username'];
    firstName = json['first_name'];
    lastName = json['last_name'];
    email = json['email'];
    dob = json['dob'];
    profileCompleted = json['profile_completed'];
    verified = json['verified'];
    bio = json['bio'];
    notification = json['notification'];
    profileImage = json['profile_image'];
    posts = json['posts'];
    following = json['following'];
    followers = json['followers'];
    token = json['token'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['name'] = name;
    data['username'] = username;
    data['first_name'] = firstName;
    data['last_name'] = lastName;
    data['email'] = email;
    data['dob'] = dob;
    data['profile_completed'] = profileCompleted;
    data['verified'] = verified;
    data['bio'] = bio;
    data['notification'] = notification;
    data['profile_image'] = profileImage;
    data['posts'] = posts;
    data['following'] = following;
    data['followers'] = followers;
    data['token'] = token;
    return data;
  }
}
