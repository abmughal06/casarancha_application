import 'dart:convert';

class MediaDetails {
  String id;
  String name;
  String type;
  String link;
  MediaDetails({
    required this.id,
    required this.name,
    required this.type,
    required this.link,
  });

  MediaDetails copyWith({
    String? id,
    String? name,
    String? type,
    String? link,
  }) {
    return MediaDetails(
      id: id ?? this.id,
      name: name ?? this.name,
      type: type ?? this.type,
      link: link ?? this.link,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'type': type,
      'link': link,
    };
  }

  factory MediaDetails.fromMap(Map<String, dynamic> map) {
    return MediaDetails(
      id: map['id'] ?? '',
      name: map['name'] ?? '',
      type: map['type'] ?? '',
      link: map['link'] ?? '',
    );
  }

  String toJson() => json.encode(toMap());

  factory MediaDetails.fromJson(String source) =>
      MediaDetails.fromMap(json.decode(source));

  @override
  String toString() {
    return 'MediaDetails(id: $id, name: $name, type: $type, link: $link)';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;

    return other is MediaDetails &&
        other.id == id &&
        other.name == name &&
        other.type == type &&
        other.link == link;
  }

  @override
  int get hashCode {
    return id.hashCode ^ name.hashCode ^ type.hashCode ^ link.hashCode;
  }
}
