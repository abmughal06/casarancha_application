import 'package:dio/dio.dart';

import 'api_urls.dart';

class ApiService {
  final dio = createDio();
  final tokenDio = Dio(BaseOptions(baseUrl: ApiUrl.baseURL));

  ApiService._internal();

  static final _singleton = ApiService._internal();

  factory ApiService() => _singleton;

  static Dio createDio() {
    var dio = Dio(BaseOptions(
      baseUrl: ApiUrl.baseURL,
      receiveTimeout: 15000, // 15 seconds
      connectTimeout: 15000,
      sendTimeout: 15000,
      validateStatus: (statusCode){
        if(statusCode == null){
          return false;
        }
        if(statusCode == 412){
          return true;
        }else{
          return statusCode >= 200 && statusCode < 300;
        }
      },
    ));

    dio.interceptors.addAll({
      AppInterceptors(dio),
    });
    return dio;
  }

}

class AppInterceptors extends Interceptor {
  final Dio dio;

  AppInterceptors(this.dio);

  @override
  Future onRequest(RequestOptions options, RequestInterceptorHandler handler) async {

    if (options.extra.containsKey('header')) {
      ///Add token while development
      /*options.headers.addAll({
        'Authorization': await getToken(),
      });*/
      // options.headers['Authorization'] = '${await getToken()}';
    }
    // options.headers['Authorization'] = '${await getToken()}';
    return handler.next(options);
  }
}
