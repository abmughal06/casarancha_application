class ApiUrl{
  static const String baseURL = "https://hexeros.com/dev/casa-rancha/api/V1/";
  static const String checkAbilityUrl = "check_ability";
  static const String signUpUrl = "signup";
  static const String sendOtpUrl = "send_otp";
  static const String loginUrl = "login";
  static const String verifyOtpUrl = "verify_otp";
  static const String resetPasswordUrl = "reset_password";
  static const String versionCheckUrl = "version_checker";
  static const String getUserProfileUrl = "user/profile";
  static const String updateProfileUrl = "user/update_profile";
  static const String updateEmailUrl = "user/update_email";
  static const String updatePasswordUrl = "user/change_password";
  static const String updateNotificationStatusUrl = "user/update_notification_status";
  static const String completeUserProfileUrl = "user/complete_profile";
  static const String logoutUSerUrl = "user/logout";
  static const String privacyUrl = "${baseURL}content/privacy_policy";
  static const String termsConditionUrl = "${baseURL}content/term&condition";
  static const String aboutUrl = "${baseURL}content/about";
}