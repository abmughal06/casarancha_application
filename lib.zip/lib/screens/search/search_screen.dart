import 'package:casarancha/models/group_model.dart';
import 'package:casarancha/models/post_model.dart';
import 'package:casarancha/models/user_model.dart';

import 'package:casarancha/screens/profile/ProfileScreen/profile_screen_controller.dart';
import 'package:casarancha/widgets/PostCard/PostCard.dart';
import 'package:casarancha/widgets/PostCard/PostCardController.dart';
import 'package:casarancha/widgets/app_user_tile.dart';
import 'package:casarancha/widgets/group_tile.dart';
import 'package:casarancha/widgets/primary_Appbar.dart';
import 'package:casarancha/widgets/text_widget.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';
import 'package:flutterfire_ui/firestore.dart';
import 'package:get/get.dart';

import '../../resources/color_resources.dart';
import '../../resources/image_resources.dart';

import '../../widgets/common_widgets.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({Key? key}) : super(key: key);

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final List<Widget> _myTabs = const [
    Tab(text: 'People'),
    Tab(text: 'Groups'),
    Tab(text: 'Location'),
  ];

  late TextEditingController searchController;
  late ProfileScreenController profilescreenController;

  @override
  void initState() {
    searchController = TextEditingController();
    profilescreenController = Get.find<ProfileScreenController>();
    super.initState();
  }

  @override
  void dispose() {
    searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: primaryAppbar(
        title: 'Search',
        elevation: 0,
      ),
      body: DefaultTabController(
        length: _myTabs.length,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 20.w),
              child: searchTextField(
                context: context,
                controller: searchController,
                onChange: (value) {
                  setState(() {});
                },
              ),
            ),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 20.w),
              child: commonTabBar(tabsList: _myTabs),
            ),
            heightBox(10.w),
            Expanded(
              child: TabBarView(
                children: [
                  /*people*/

                  FirestoreListView(
                    query: FirebaseFirestore.instance.collection('users').where(
                          'username',
                          isEqualTo: searchController.text.trim(),
                        ),
                    padding: EdgeInsets.symmetric(
                      vertical: 10.w,
                      horizontal: 20.w,
                    ),
                    itemBuilder: (context,
                        QueryDocumentSnapshot<Map<String, dynamic>> doc) {
                      final user = UserModel.fromMap(doc.data());

                      return AppUserTile(
                        appUser: user,
                        currentUserId: profilescreenController.user.value.id,
                      );
                    },
                  ),

                  /*group*/
                  FirestoreListView(
                    query:
                        FirebaseFirestore.instance.collection('groups').where(
                              'name',
                              isEqualTo: searchController.text.trim(),
                            ),
                    padding: EdgeInsets.symmetric(
                      vertical: 10.w,
                      horizontal: 20.w,
                    ),
                    itemBuilder: (context,
                        QueryDocumentSnapshot<Map<String, dynamic>> doc) {
                      final group = GroupModel.fromMap(doc.data());

                      return GroupTile(
                        group: group,
                        currentUserId: profilescreenController.user.value.id,
                      );
                    },
                  ),

                  /*location*/
                  FirestoreListView(
                    query: FirebaseFirestore.instance.collection('posts').where(
                          'locationName',
                          isEqualTo: searchController.text.trim(),
                        ),
                    itemBuilder: (context,
                        QueryDocumentSnapshot<Map<String, dynamic>> doc) {
                      final post = PostModel.fromMap(doc.data());
                      final postCardController = Get.put(
                        PostCardController(
                          postdata: post,
                        ),
                        tag: post.id,
                      );
                      return PostCard(
                        postCardController: postCardController,
                      );
                    },
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
