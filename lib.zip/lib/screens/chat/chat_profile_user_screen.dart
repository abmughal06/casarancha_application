import 'package:casarancha/resources/color_resources.dart';
import 'package:casarancha/screens/chat/video_call_screen.dart';
import 'package:casarancha/widgets/common_appbar.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';
import '../../base/base_stateful_widget.dart';
import '../../models/chat_page/chat_message.dart';
import '../../resources/image_resources.dart';
import '../../resources/localization_text_strings.dart';
import '../../resources/strings.dart';
import '../../utils/app_constants.dart';
import '../../widgets/clip_pad_shadow.dart';
import '../../widgets/common_widgets.dart';
import '../../widgets/text_widget.dart';
import 'audio_call_screen.dart';

class ChatProfileUserScreen extends StatefulWidget {
  const ChatProfileUserScreen({Key? key}) : super(key: key);

  @override
  State<ChatProfileUserScreen> createState() => _ChatProfileUserScreenState();
}

class _ChatProfileUserScreenState
    extends BaseStatefulWidgetState<ChatProfileUserScreen> {
  final List<ChatMessage> message = [
    ChatMessage(
      msgText: "Good Morning Melvin",
      time: "05:23",
      isSendByMe: true,
    ),
    ChatMessage(
        msgText: "Hey.. Very Very Good Morning ",
        time: "05:24",
        isSendByMe: false),
    ChatMessage(
      msgText: "When you call me i was on the Mountain",
      time: "05:25",
      isSendByMe: false,
      separateTime: "Today - July 26, 2022",
    ),
    ChatMessage(msgText: "Fine", time: "05:26", isSendByMe: false),
    ChatMessage(msgText: "Hello", time: "05:23", isSendByMe: true),
  ];

  @override
  PreferredSizeWidget? buildAppBar(BuildContext context) {
    return iosBackIcAppBar(
        onTapLead: () => goBack(),
        customTitle: Align(
          alignment: Alignment.centerLeft,
          child: Row(
            children: [
              imgProVerified(
                profileImg: postImgTemp,
                idIsVerified: false,
                imgRadius: 16.r,
              ),
              widthBox(10.w),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      TextWidget(
                        text: "ABS..-2",
                        color: color13F,
                        fontWeight: FontWeight.w600,
                        fontSize: 14.sp,
                      ),
                      widthBox(6.w),
                      SvgPicture.asset(icVerifyBadge),
                    ],
                  ),
                  // TextWidget(
                  //   text: "5 min ago at New York",
                  //   color:  color887,
                  //   fontWeight:  FontWeight.w400,
                  //   fontSize:  11.sp,
                  // ),
                  Row(
                    children: [
                      Container(
                        height: 5.h,
                        width: 5.w,
                        decoration: BoxDecoration(
                          color: color31D,
                          borderRadius: BorderRadius.circular(16.r),
                        ),
                      ),
                      widthBox(6.w),
                      TextWidget(
                        text: "Live",
                        color: color221,
                        fontWeight: FontWeight.w400,
                        fontSize: 12.sp,
                      ),
                    ],
                  )
                ],
              )
            ],
          ),
        ),
        actionsWidgets: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: svgImgButton(svgIcon: icChatVideo,onTap: (){
              push(context, enterPage: const VideoCallScreen());
            }),
          ),
          Padding(
            padding: EdgeInsets.only(left: 8.w, right: 20.w),
            child: svgImgButton(svgIcon: icChatCall , onTap: (){
              push(context, enterPage: const AudioCallScreen());
            }),
          ),
        ]);
  }

  @override
  Widget buildBody(BuildContext context) {
    return LayoutBuilder(
        builder: (BuildContext context, BoxConstraints constraints) {
      return ConstrainedBox(
          constraints: BoxConstraints(minHeight: constraints.minHeight),
          child: Stack(
            children: [
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 20.w),
                child: ListView.separated(
                  itemCount: message.length,
                  shrinkWrap: true,
                  padding: const EdgeInsets.only(top: 10, bottom: 10),
                  physics: const BouncingScrollPhysics(),
                  itemBuilder: (context, index) {
                    return Column(
                      children: [
                        Align(
                          alignment: message[index].isSendByMe
                              ? Alignment.topRight
                              : Alignment.topLeft,
                          child: Container(
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.only(
                                    topLeft: Radius.circular(16.r),
                                    topRight: Radius.circular(16.r),
                                    bottomLeft: Radius.circular(
                                        message[index].isSendByMe ? 16.r : 0),
                                    bottomRight: Radius.circular(
                                        message[index].isSendByMe ? 0 : 16.r)),
                                color: (message[index].isSendByMe
                                    ? colorF03
                                    : colorFF4),
                              ),
                              padding: EdgeInsets.symmetric(
                                  horizontal: 20.w, vertical: 16.h),
                              child: TextWidget(
                                text: message[index].msgText ?? "",
                                color: message[index].isSendByMe
                                    ? color13F
                                    : color55F,
                                fontWeight: FontWeight.w500,
                              )),
                        ),
                        Align(
                          alignment: message[index].isSendByMe
                              ? Alignment.centerRight
                              : Alignment.centerLeft,
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              message[index].isSendByMe ?   Padding(
                                padding:  EdgeInsets.symmetric(horizontal: 3.w),
                                child: SvgPicture.asset(icChatMsgSend),
                              ) : Container(),
                              TextWidget(
                                text: message[index].time,
                                color: colorAA3,
                                fontSize: 11.sp,
                              ),
                            ],
                          ),
                        )
                      ],
                    );
                  },
                  separatorBuilder: (BuildContext context, int index) {
                    return message[index].separateTime != null
                        ? Center(
                            child: Padding(
                              padding: EdgeInsets.symmetric(vertical: 18.h),
                              child: TextWidget(
                                text: message[index].separateTime,
                                color: color221,
                                fontSize: 11.sp,
                              ),
                            ),
                          )
                        : Container();
                  },
                ),
              ),
              Align(
                alignment: Alignment.bottomCenter,
                child: ClipRect(
                  clipper: const ClipPad(padding: EdgeInsets.only(top: 30)),
                  child: Container(
                    padding: EdgeInsets.symmetric(horizontal: 20.w),
                    decoration: BoxDecoration(color: colorWhite, boxShadow: [
                      BoxShadow(
                        color: colorPrimaryA05.withOpacity(.36),
                        spreadRadius: 1,
                        blurRadius: 5,
                        offset: const Offset(4, 0),
                      ),
                    ]),
                    child: TextField(
                      style: TextStyle(
                        color: color239,
                        fontSize: 16.sp,
                        fontFamily: strFontName,
                        fontWeight: FontWeight.w600,
                      ),
                      decoration: InputDecoration(
                        isDense: true,
                        hintText: strSaySomething,
                        hintStyle: TextStyle(
                          color: color55F,
                          fontSize: 14.sp,
                          fontFamily: strFontName,
                          fontWeight: FontWeight.w400,
                        ),
                        suffixIcon: Padding(
                            padding: const EdgeInsets.all(10.0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                svgImgButton(svgIcon: icChatPaperClip),
                                widthBox(12.w),
                                GestureDetector(
                                    onTap: () {},
                                    child: Image.asset(
                                      imgSendComment,
                                      height: 38.h,
                                      width: 38.w,
                                    )),
                              ],
                            )),
                        contentPadding: EdgeInsets.symmetric(
                            horizontal: 12.w, vertical: 20.h),
                        focusColor: Colors.transparent,
                        focusedBorder: const OutlineInputBorder(
                          borderSide: BorderSide(
                            width: 0,
                            color: Colors.transparent,
                          ),
                        ),
                      ),
                      keyboardType: TextInputType.text,
                      textInputAction: TextInputAction.done,
                      onEditingComplete: () => FocusScope.of(context).unfocus(),
                    ),
                  ),
                ),
              ),
            ],
          ));
    });
  }
}
