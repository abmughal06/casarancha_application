import 'package:casarancha/resources/color_resources.dart';
import 'package:casarancha/widgets/common_widgets.dart';
import 'package:casarancha/widgets/home_page_widgets.dart';
import 'package:casarancha/widgets/text_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../base/base_stateful_widget.dart';
import '../../resources/image_resources.dart';
import '../../resources/localization_text_strings.dart';
import '../../utils/app_constants.dart';
import '../../widgets/common_appbar.dart';

import 'chat_profile_user_screen.dart';

class ChatListScreen extends StatefulWidget {
  const ChatListScreen({Key? key}) : super(key: key);

  @override
  State<ChatListScreen> createState() => _ChatListScreenState();
}

class _ChatListScreenState extends BaseStatefulWidgetState<ChatListScreen> {
  @override
  PreferredSizeWidget? buildAppBar(BuildContext context) {
    return whiteBgAppBar(
        title: strMessages,
        elevation: 0,
        fontSize: 18.sp,
        actionsWidgets: [
          GestureDetector(
              onTap: () {},
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 18.0),
                child: Image.asset(
                  imgAddPost,
                  height: 28.h,
                  width: 28.w,
                ),
              )),
        ]);
  }

  @override
  bool get resizeBottom => false;

  @override
  Widget buildBody(BuildContext context) {
    return WillPopScope(
      onWillPop: () => Future.value(false),
      child: LayoutBuilder(
        builder: (BuildContext context, BoxConstraints constraints) {
          return ConstrainedBox(
            constraints: BoxConstraints(minHeight: constraints.minHeight),
            child: Stack(
              children: [
                Padding(
                  padding:
                      EdgeInsets.symmetric(horizontal: 20.w, vertical: 5.h),
                  child: Column(
                    children: [
                      searchTextField(
                          context: context, hintText: strSearchHere),
                      heightBox(10.h),
                      Expanded(
                        child: ListView.separated(
                          shrinkWrap: true,
                          itemCount: 10,
                          padding: EdgeInsets.only(bottom: 65.h),
                          physics: const BouncingScrollPhysics(),
                          itemBuilder: (BuildContext context, int index) {
                            return GestureDetector(
                              onTap: () => push(context,
                                  enterPage: const ChatProfileUserScreen()),
                              child: SizedBox(
                                height: 76.h,
                                child: Padding(
                                  padding: EdgeInsets.symmetric(vertical: 14.h),
                                  child: Center(
                                    child: Row(
                                      children: [
                                        SizedBox(
                                          width: screenSize.width * 0.75,
                                          child: profileImgName(
                                              dpRadius: 21.r,
                                              imgUserNet: postProfileImg,
                                              isVerifyWithIc: false,
                                              isVerifyWithName: true,
                                              idIsVerified: true,
                                              userName: "Jane_889",
                                              userNameFontWeight:
                                                  FontWeight.w600,
                                              userNameClr: color229,
                                              subText: index % 4 == 0
                                                  ? "good morning Hey Hello how are  ?"
                                                  : "Where are you now brosdf ",
                                              subTxtWidth: 190.w,
                                              subTxtFontWeight: index % 4 == 0
                                                  ? FontWeight.w700
                                                  : FontWeight.w400,
                                              subTxtClr: index % 4 == 0
                                                  ? colorBlack
                                                  : color88A,
                                              subTxtFontSize: 14.sp),
                                        ),
                                        const Spacer(),
                                        Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.end,
                                          children: [
                                            TextWidget(
                                              text: "15 min",
                                              color: color887,
                                              fontSize: 12.sp,
                                            ),
                                            heightBox(3.h),
                                            Container(
                                              padding: const EdgeInsets.all(1),
                                              decoration: BoxDecoration(
                                                color: color746,
                                                borderRadius:
                                                    BorderRadius.circular(20.r),
                                              ),
                                              constraints: BoxConstraints(
                                                minWidth: 20.w,
                                                minHeight: 20.h,
                                              ),
                                              child: Center(
                                                child: TextWidget(
                                                  text: "15",
                                                  color: colorWhite,
                                                  fontSize: 12.sp,
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            );
                          },
                          separatorBuilder: (BuildContext context, int index) {
                            return Padding(
                              padding: EdgeInsets.symmetric(horizontal: 16.w),
                              child: horizonLine(width: constraints.maxWidth),
                            );
                          },
                        ),
                      )
                    ],
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
