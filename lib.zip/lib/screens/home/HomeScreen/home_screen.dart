import 'package:cached_network_image/cached_network_image.dart';
import 'package:casarancha/models/post_model.dart';
import 'package:casarancha/models/story_model.dart';
import 'package:casarancha/resources/color_resources.dart';
import 'package:casarancha/resources/strings.dart';
import 'package:casarancha/screens/home/HomeScreen/home_screen_controller.dart';
import 'package:casarancha/screens/home/CreateStory/add_story_screen.dart';
import 'package:casarancha/screens/home/story_view_screen.dart';
import 'package:casarancha/screens/home/view_post_screen.dart';
import 'package:casarancha/widgets/PostCard/PostCard.dart';
import 'package:casarancha/widgets/PostCard/PostCardController.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';
import 'package:flutterfire_ui/database.dart';
import 'package:flutterfire_ui/firestore.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';
import 'package:video_player/video_player.dart';
import '../../../resources/image_resources.dart';
import '../../../resources/localization_text_strings.dart';
import '../../../utils/app_constants.dart';
import '../../../utils/music_page_manager.dart';
import '../../../view_models/home_vm/home_screen_view_model.dart';
import '../../../widgets/common_appbar.dart';

import '../../../widgets/common_widgets.dart';
import '../../../widgets/home_page_widgets.dart';
import '../CreatePost/create_post_screen.dart';
import '../notification_screen.dart';

class HomeScreen extends StatelessWidget {
  HomeScreen({Key? key}) : super(key: key);

  final homeScreenController = Get.put(HomeScreenController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        centerTitle: true,
        title: Text(
          strCasaRanch,
          style: TextStyle(
            color: color13F,
            fontFamily: strFontName,
            fontWeight: FontWeight.w700,
            fontSize: 22.sp,
          ),
        ),
        elevation: 3,
        leading: IconButton(
          onPressed: () {},
          icon: SvgPicture.asset(
            icGhostMode,
          ),
        ),
        actions: [
          IconButton(
            onPressed: () {
              Get.to(() => CreatePostScreen());
            },
            icon: Image.asset(
              imgAddPost,
            ),
          ),
          IconButton(
            onPressed: () {
              Get.to(() => const NotificationScreen());
            },
            icon: SvgPicture.asset(
              icNotifyBell,
            ),
          ),
        ],
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
            margin: EdgeInsets.symmetric(
              vertical: 10.w,
            ),
            height: 50.h,
            child: Row(
              children: [
                Padding(
                  padding: EdgeInsets.only(left: 20.w, right: 5.w),
                  child: GestureDetector(
                    onTap: () {
                      Get.to(() => AddStoryScreen());
                    },
                    child: SvgPicture.asset(
                      icProfileAdd,
                      height: 50.h,
                      width: 50.w,
                    ),
                  ),
                ),
                Expanded(
                  child: Center(
                    child: FirestoreListView(
                      scrollDirection: Axis.horizontal,
                      query: FirebaseFirestore.instance.collection('stories'),
                      itemBuilder: (context,
                          QueryDocumentSnapshot<Map<String, dynamic>> doc) {
                        final Story story = Story.fromMap(doc.data());
                        return Padding(
                          padding: EdgeInsets.symmetric(horizontal: 5.w),
                          child: GestureDetector(
                            onTap: () {
                              Get.to(
                                () => StoryViewScreen(
                                  story: story,
                                ),
                              );
                            },
                            child: CachedNetworkImage(
                              imageUrl: story.creatorDetails.imageUrl,
                              imageBuilder: (context, imageProvider) => Stack(
                                children: [
                                  CircleAvatar(
                                    radius: 25.r,
                                    backgroundImage: imageProvider,
                                  ),
                                ],
                              ),
                              placeholder: (context, url) => shimmerImg(
                                  child: CircleAvatar(
                                radius: 25.r,
                              )),
                              errorWidget: (context, url, error) => SizedBox(
                                height: 25.r,
                                width: 25.r,
                                child: const Icon(
                                  Icons.error,
                                ),
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: ShowAllPosts(
              query: homeScreenController.postQuerry,
            ),
          ),
        ],
      ),
      //  ListView(
      //   children: [
      //     SizedBox(
      //       height: 74.h,
      //       child: SingleChildScrollView(
      //         scrollDirection: Axis.horizontal,
      //         physics: const BouncingScrollPhysics(),
      //         child: Row(
      //           mainAxisSize: MainAxisSize.max,
      //           children: [
      //             Padding(
      //               padding: EdgeInsets.only(left: 20.w, right: 5.w),
      //               child: GestureDetector(
      //                 onTap: () {
      //                   // push(context, enterPage: const AddStoryScreen());
      //                 },
      //                 child: SvgPicture.asset(
      //                   icProfileAdd,
      //                   height: 50.h,
      //                   width: 50.w,
      //                 ),
      //               ),
      //             ),
      //             ListView.builder(
      //                 shrinkWrap: true,
      //                 physics: const NeverScrollableScrollPhysics(),
      //                 itemCount: 15,
      //                 scrollDirection: Axis.horizontal,
      //                 itemBuilder: (BuildContext context, int index) {
      //                   return Padding(
      //                     padding: EdgeInsets.symmetric(horizontal: 5.w),
      //                     child: GestureDetector(
      //                       onTap: () {
      //                         // push(context,
      //                         //     enterPage: const StoryViewScreen());
      //                       },
      //                       child: SizedBox(
      //                         height: 60.h,
      //                         child: Center(
      //                             child: imgProVerified(
      //                                 profileImg: storyProfileImg,
      //                                 idIsVerified: true,
      //                                 imgRadius: 25.r)),
      //                       ),
      //                     ),
      //                   );
      //                 }),
      //           ],
      //         ),
      //       ),
      //     ),
      //     Expanded(
      //       child: FirestoreListView(
      //         physics: const NeverScrollableScrollPhysics(),
      //         query: FirebaseFirestore.instance.collection('posts'),
      //         itemBuilder:
      //             (context, QueryDocumentSnapshot<Map<String, dynamic>> doc) {
      //           final post = PostModel.fromMap(doc.data());
      //           return PostCard(
      //             post: post,
      //             currentUserId: homeScreenController.currentUserId,
      //           );
      //         },
      //       ),
      //     )
      //     // ListView.builder(
      //     //     shrinkWrap: true,
      //     //     physics: const ClampingScrollPhysics(),
      //     //     // physics: const NeverScrollableScrollPhysics(),
      //     //     itemCount: 10,
      //     //     itemBuilder: (BuildContext context, int index) {
      //     //       return feedCardPost(
      //     //           index: index,
      //     //           screenSize: Size(double.infinity, double.infinity),
      //     //           context: context,
      //     //           viewModel: HomeScreenViewModel(),
      //     //           width: double.infinity,
      //     //           imgUserNet: postProfileImg,
      //     //           userName: "Codyb.842",
      //     //           lastSeen: "5 min ago at New York",
      //     //           isVerify: true,
      //     //           likeCount: "16",
      //     //           commentCount: "8",
      //     //           postDescriptionStr: postDescription,
      //     //           textQuotaPost: "Hello guys this is the first time i am "
      //     //               "using one of the Cool Social media platform its gave many so many "
      //     //               "friends and family members please let me know if i may be your friend ",
      //     //           postType: PostType.quote,
      //     //           onTapSharePost: () {
      //     //             sharePostBottomSheet(context: context);
      //     //           },
      //     //           onTapPost: () => Get.to(() => const ViewPostScreen()),
      //     //           onTapCardMenu: () {
      //     //             bottomSheetPostMenu(
      //     //                 contextMenu: context,
      //     //                 bottomSheetMenuType: BottomSheetMenuType.isPostMenu);
      //     //           });
      //     // return index == 0
      //     //     ?
      //     //     : index == 1
      //     //         ? feedCardPost(
      //     //             index: index,
      //     //             screenSize: screenSize,
      //     //             context: context,
      //     //             viewModel: homeScreenViewModel,
      //     //             width: constraints.maxWidth,
      //     //             imgUserNet: postProfileImg,
      //     //             userName: "Codyb.842",
      //     //             lastSeen: "5 min ago at New York",
      //     //             isVerify: true,
      //     //             likeCount: "186",
      //     //             commentCount: "85",
      //     //             postDescriptionStr: postDescription,
      //     //             imgUrlPost: musicImgUrl,
      //     //             musicManager: _musicManager,
      //     //             musicUrl: musicMp3,
      //     //             songTitle: "As It Was",
      //     //             albumTitle: "Harry Styles",
      //     //             textQuotaPost:
      //     //                 "Hello guys this is the first time i am "
      //     //                 "using one of the Cool Social media platform its gave many so many "
      //     //                 "friends and family members please let me know if i may be your friend ",
      //     //             postType: PostType.music,
      //     //             onTapSharePost: () {
      //     //               sharePostBottomSheet(context: context);
      //     //             },
      //     //             onTapPost: () => push(context,
      //     //                 enterPage: const ViewPostScreen()),
      //     //             onTapCardMenu: () {
      //     //               bottomSheetPostMenu(
      //     //                   contextMenu: context,
      //     //                   bottomSheetMenuType:
      //     //                       BottomSheetMenuType.isPostMenu);
      //     //             })
      //     //         : index == 4
      //     //             ? feedCardPost(
      //     //                 index: index,
      //     //                 screenSize: screenSize,
      //     //                 context: context,
      //     //                 viewModel: homeScreenViewModel,
      //     //                 width: constraints.maxWidth,
      //     //                 imgUserNet: postProfileImg,
      //     //                 userName: "Codyb.842",
      //     //                 lastSeen: "5 min ago at New York",
      //     //                 isVerify: true,
      //     //                 likeCount: "186",
      //     //                 commentCount: "85",
      //     //                 postDescriptionStr: postDescription,
      //     //                 postType: PostType.video,
      //     //                 videoController: _videoController,
      //     //                 initializeVideoPlayerFuture:
      //     //                     _initializeVideoPlayerFuture,
      //     //                 onTapSharePost: () {
      //     //                   sharePostBottomSheet(context: context);
      //     //                 },
      //     //                 onTapPost: () => push(context,
      //     //                     enterPage: const ViewPostScreen()),
      //     //                 onTapCardMenu: () {
      //     //                   bottomSheetPostMenu(
      //     //                       contextMenu: context,
      //     //                       bottomSheetMenuType:
      //     //                           BottomSheetMenuType.isPostMenu);
      //     //                 })
      //     //             : feedCardPost(
      //     //                 context: context,
      //     //                 screenSize: screenSize,
      //     //                 viewModel: homeScreenViewModel,
      //     //                 width: constraints.maxWidth,
      //     //                 imgUserNet: postProfileImg,
      //     //                 userName: "Codyb.842",
      //     //                 lastSeen: "5 min ago at New York",
      //     //                 isVerify: false,
      //     //                 likeCount: "120",
      //     //                 commentCount: "5",
      //     //                 postDescriptionStr: postDescription,
      //     //                 imgUrlPost: postImgTemp,
      //     //                 postType: PostType.image,
      //     //                 onTapSharePost: () {
      //     //                   sharePostBottomSheet(context: context);
      //     //                 },
      //     //                 onTapCardMenu: () {
      //     //                   bottomSheetPostMenu(
      //     //                       contextMenu: context,
      //     //                       bottomSheetMenuType:
      //     //                           BottomSheetMenuType.isPostMenu);
      //     //                 },
      //     // onTapLikeIc: () => homeScreenViewModel!
      //     //     .onTapLikePost(index: index),
      //     //   onTapPost: () => push(context,
      //     //       enterPage: const ViewPostScreen()),
      //     //   index: index,
      //     // );
      //     // }),
      //   ],
      // ),
    );
  }
}

class ShowAllPosts extends StatelessWidget {
  const ShowAllPosts({
    Key? key,
    required this.query,
    this.physics,
    this.shrinkWrap = false,
  }) : super(key: key);

  final Query<Map<String, dynamic>> query;
  final ScrollPhysics? physics;
  final bool shrinkWrap;

  @override
  Widget build(BuildContext context) {
    return FirestoreListView(
      shrinkWrap: shrinkWrap,
      physics: physics,
      query: query,
      itemBuilder: (context, QueryDocumentSnapshot<Map<String, dynamic>> doc) {
        final post = PostModel.fromMap(doc.data());
        final postCardController = Get.put(
          PostCardController(
            postdata: post,
          ),
          tag: post.id,
        );
        return PostCard(
          postCardController: postCardController,
        );
      },
    );
  }
}
