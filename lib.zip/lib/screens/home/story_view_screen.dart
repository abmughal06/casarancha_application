import 'package:cached_network_image/cached_network_image.dart';
import 'package:casarancha/models/story_model.dart';
import 'package:casarancha/widgets/home_page_widgets.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:story_view/story_view.dart';
import 'package:timeago/timeago.dart' as timeago;

import '../../resources/color_resources.dart';
import '../../resources/image_resources.dart';
import '../../resources/localization_text_strings.dart';
import '../../resources/strings.dart';
import '../../utils/app_constants.dart';

import '../../widgets/common_widgets.dart';

class StoryViewScreen extends StatefulWidget {
  const StoryViewScreen({Key? key, required this.story}) : super(key: key);

  final Story story;

  @override
  State<StoryViewScreen> createState() => _StoryViewScreenState();
}

class _StoryViewScreenState extends State<StoryViewScreen> {
  late StoryController controller;
  late TextEditingController commentController;
  final FocusNode _commentFocus = FocusNode();

  List<StoryItem> storyItems = [];

  @override
  void initState() {
    controller = StoryController();
    commentController = TextEditingController();
    super.initState();
  }

  @override
  void dispose() {
    controller.dispose();
    commentController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final dateText = timeago.format(DateTime.parse(widget.story.createdAt));
    return SafeArea(
      child: Scaffold(
        body: Stack(
          children: [
            Expanded(
              child: StoryView(
                  storyItems: [
                    ...widget.story.mediaDetailsList.map(
                      (e) => StoryItem.pageImage(
                        url: e.link,
                        controller: controller,
                      ),
                    )
                  ],
                  controller: controller,
                  onComplete: () {
                    Get.back();
                  },
                  onVerticalSwipeComplete: (direction) {
                    if (direction == Direction.down) {
                      Get.back();
                    }
                  }),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Padding(
                  padding: EdgeInsets.only(left: 20.w, right: 20.w, top: 20.h),
                  child: profileImgName(
                    imgUserNet: widget.story.creatorDetails.imageUrl,
                    isVerifyWithIc: widget.story.creatorDetails.isVerified,
                    isVerifyWithName: false,
                    idIsVerified: widget.story.creatorDetails.isVerified,
                    dpRadius: 17.r,
                    userName: widget.story.creatorDetails.name,
                    userNameClr: colorWhite,
                    userNameFontSize: 12.sp,
                    userNameFontWeight: FontWeight.w600,
                    subText: dateText,
                    subTxtFontSize: 9.sp,
                    subTxtClr: colorWhite.withOpacity(.5),
                  ),
                ),
                Container(),
                // Align(
                //   alignment: Alignment.bottomCenter,
                //   child: Padding(
                //     padding: const EdgeInsets.all(10.0),
                //     child: Focus(
                //       focusNode: _commentFocus,
                //       onFocusChange: (hasFocus) {
                //         hasFocus ? controller.pause() : null;
                //       },
                //       child: TextFormField(
                //         controller: commentController,
                //         onChanged: (val) {
                //           controller.pause();
                //         },
                //         style: TextStyle(
                //           color: color887,
                //           fontSize: 16.sp,
                //           fontFamily: strFontName,
                //           fontWeight: FontWeight.w500,
                //         ),
                //         decoration: InputDecoration(
                //           hintText: strWriteCommentHere,
                //           hintStyle: TextStyle(
                //             color: color887,
                //             fontSize: 14.sp,
                //             fontFamily: strFontName,
                //             fontWeight: FontWeight.w400,
                //           ),
                //           suffixIcon: Padding(
                //             padding: EdgeInsets.symmetric(horizontal: 10.w),
                //             child: svgImgButton(
                //                 svgIcon: icStoryCmtSend,
                //                 onTap: () {
                //                   if (kDebugMode) {
                //                     print("comment == " +
                //                         commentController.text.toString());
                //                   }
                //                   FocusScope.of(context).unfocus();
                //                   commentController.text = "";
                //                   controller.play();
                //                 }),
                //           ),
                //           contentPadding: EdgeInsets.symmetric(
                //               horizontal: 12.w, vertical: 12.h),
                //           filled: true,
                //           fillColor: Colors.transparent,
                //           border: OutlineInputBorder(
                //               borderRadius: BorderRadius.circular(16.0),
                //               borderSide: BorderSide.none),
                //           focusedBorder: OutlineInputBorder(
                //             borderRadius: BorderRadius.circular(30.r),
                //             borderSide: const BorderSide(
                //               color: color887,
                //             ),
                //           ),
                //           enabledBorder: OutlineInputBorder(
                //             borderRadius: BorderRadius.circular(30.r),
                //             borderSide: const BorderSide(
                //               color: color887,
                //               width: 1.0,
                //             ),
                //           ),
                //         ),
                //         textInputAction: TextInputAction.done,
                //         onFieldSubmitted: (val) {
                //           FocusScope.of(context).unfocus();
                //           commentController.text = "";
                //           controller.play();
                //         },
                //         onEditingComplete: () {
                //           FocusScope.of(context).unfocus();
                //           commentController.text = "";
                //           controller.play();
                //         },
                //       ),
                //     ),
                //   ),
                // )
              ],
            ),
          ],
        ),
      ),
    );
  }
}
