import 'dart:io';

import 'package:casarancha/screens/profile/ProfileScreen/profile_screen.dart';
import 'package:casarancha/serivces/setting/setting_services.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

import '../../base/base_stateful_widget.dart';
import '../../models/auth/signup_model.dart';
import '../../models/common/success_with_msg_model.dart';
import '../../resources/color_resources.dart';
import '../../resources/image_resources.dart';
import '../../resources/localization_text_strings.dart';
import '../../resources/strings.dart';
import '../../serivces/auth/set_profile_service.dart';
import '../../serivces/common_service.dart';
import '../../utils/app_constants.dart';
import '../../utils/app_utils.dart';
import '../../utils/custom_date_picker.dart';
import '../../utils/snackbar.dart';
import '../../view_models/profile_vm/edit_profie_view_model.dart';
import '../../widgets/common_appbar.dart';
import '../../widgets/common_button.dart';
import '../../widgets/common_widgets.dart';
import '../../widgets/text_editing_widget.dart';
import '../../widgets/text_widget.dart';

class EditProfileScreen extends StatefulWidget {
  const EditProfileScreen({Key? key}) : super(key: key);

  @override
  State<EditProfileScreen> createState() => _EditProfileScreenState();
}

class _EditProfileScreenState
    extends BaseStatefulWidgetState<EditProfileScreen> {
  final TextEditingController _firstNameController = TextEditingController();
  final TextEditingController _lastNameController = TextEditingController();
  final TextEditingController _userNameController = TextEditingController();
  final TextEditingController _bioController = TextEditingController();
  SuccessWithMsg isValidUsername = SuccessWithMsg(isSuccess: false);
  String? _profileImage, _selectedDob;
  DateTime? _getDateTime;
  List<bool> showSelectedDates = [false, false, false]; // day , month , year
  EditProfileScViewModel? editProfileScViewModel;

  FormData? formData;
  File? imageFilePicked;
  String bioTxtCount = "0";
  SignupResponseModel? _resProfileData;

  @override
  void initState() {
    statusBarDarkMode();
    getProfileData();
    super.initState();
  }

  Future getProfileData() async {
    editProfileScViewModel =
        Provider.of<EditProfileScViewModel>(context, listen: false);
    if (await AppConstant.checkNetwork()) {
      editProfileScViewModel!.onStartLoader();
      _resProfileData = await SetProfileService().getProfileData();
      if (_resProfileData != null) {
        _firstNameController.text = _resProfileData!.firstName ?? "";
        _lastNameController.text = _resProfileData!.lastName ?? "";
        _userNameController.text = _resProfileData!.username ?? "";
        _bioController.text = _resProfileData!.bio ?? "";
        bioTxtCount = _bioController.text.length.toString();
        _profileImage = _resProfileData!.profileImage;
        _selectedDob = _resProfileData!.dob.toString();
        if (_selectedDob != null && _selectedDob != "") {
          List dobTemp = _selectedDob!.split("-");
          _getDateTime = DateTime(int.parse(dobTemp[0]), int.parse(dobTemp[1]),
              int.parse(dobTemp[2]));
          showSelectedDates = [true, true, true];
        }
      } else {
        AppConstant.globalToast("Unable to fetch profile data");
      }
      editProfileScViewModel!.onStopLoader();
    }
  }

  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
  }

  @override
  Color? get scaffoldBgColor => colorWhite;

  @override
  bool get shouldHaveSafeArea => false;

  @override
  PreferredSizeWidget? buildAppBar(BuildContext context) {
    return iosBackIcAppBar(
      title: strEditProfile,
      onTapLead: () => goBack(),
    );
  }

  _getFromGallery() async {
    XFile? pickedFile = await ImagePicker().pickImage(
      source: ImageSource.gallery,
    );
    if (pickedFile != null) {
      imageFilePicked = File(pickedFile.path);
    }
    if (!mounted) return;
    Provider.of<EditProfileScViewModel>(context, listen: false)
        .onNotifyListeners();
  }

  bool _checkValidData() {
    if (_firstNameController.text.isEmpty) {
      GlobalSnackBar.show(
          context: context, message: 'Please enter $strFirstName');
      return false;
    } else if (_lastNameController.text.isEmpty) {
      GlobalSnackBar.show(
          context: context, message: 'Please enter $strLastName');
      return false;
    } else if (_userNameController.text.isEmpty) {
      GlobalSnackBar.show(
          context: context, message: "Please Enter $strUserName");
      return false;
    } else if (!isValidUsername.isSuccess &&
        _userNameController.text != _resProfileData?.username) {
      GlobalSnackBar.show(
          context: context,
          message: isValidUsername.msgText ?? "Invalid $strUserName");
      return false;
    } else if (_bioController.text.isEmpty) {
      GlobalSnackBar.show(context: context, message: 'Please enter $strBio');
      return false;
    } else if (_selectedDob == null || _selectedDob == "") {
      GlobalSnackBar.show(
          context: context, message: 'Please enter $strDateOfBirth');
      return false;
    } else if (imageFilePicked == null && _profileImage == null) {
      GlobalSnackBar.show(context: context, message: 'Please select image');
      return false;
    }
    return true;
  }

  @override
  Widget buildBody(BuildContext context) {
    editProfileScViewModel = Provider.of<EditProfileScViewModel>(context);
    return LayoutBuilder(
      builder: (BuildContext context, BoxConstraints constraints) {
        return ConstrainedBox(
          constraints: BoxConstraints(minHeight: constraints.minHeight),
          child: Stack(
            children: [
              SingleChildScrollView(
                child: Padding(
                  padding: const EdgeInsets.all(20.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      heightBox(37.h),
                      GestureDetector(
                        onTap: _getFromGallery,
                        child: SizedBox(
                          height: 127.h,
                          width: 127.w,
                          child: Stack(
                            clipBehavior: Clip.none,
                            fit: StackFit.expand,
                            children: [
                              imageFilePicked != null
                                  ? CircleAvatar(
                                      radius: 20,
                                      backgroundImage:
                                          Image.file(imageFilePicked!).image)
                                  : _profileImage != null
                                      ? imgProVerified(
                                          imgRadius: 80,
                                          profileImg: _profileImage,
                                          idIsVerified: false)
                                      : CircleAvatar(
                                          radius: 20,
                                          backgroundImage:
                                              Image.asset(imgProfile).image),
                              Positioned(
                                  bottom: 5.h,
                                  right: 8.w,
                                  child: SvgPicture.asset(icProfileAdd))
                            ],
                          ),
                        ),
                      ),
                      heightBox(31.h),
                      TextEditingWidget(
                        controller: _firstNameController,
                        hintColor: color080,
                        isShadowEnable: false,
                        hint: strFirstName,
                        color: colorFF4,
                        textInputType: TextInputType.text,
                        textInputAction: TextInputAction.next,
                        onEditingComplete: () =>
                            FocusScope.of(context).nextFocus(),
                      ),
                      heightBox(9.h),
                      TextEditingWidget(
                        controller: _lastNameController,
                        hintColor: color080,
                        isShadowEnable: false,
                        hint: strLastName,
                        color: colorFF4,
                        textInputType: TextInputType.text,
                        textInputAction: TextInputAction.next,
                        onEditingComplete: () =>
                            FocusScope.of(context).nextFocus(),
                      ),
                      heightBox(9.h),
                      TextEditingWidget(
                        controller: _userNameController,
                        hintColor: color080,
                        isShadowEnable: false,
                        hint: strUserName,
                        color: colorFF4,
                        textInputType: TextInputType.text,
                        textInputAction: TextInputAction.next,
                        onChanged: (val) async {
                          Future.delayed(const Duration(milliseconds: 300),
                              () async {
                            if (await AppConstant.checkNetwork()) {
                              isValidUsername = await CommonServices()
                                  .checkAbility(
                                      userId: _resProfileData!.id,
                                      strValue: val,
                                      abilityType:
                                          CheckAbilityTypeEnum.username);
                              editProfileScViewModel!.onNotifyListeners();
                            }
                          });
                        },
                        onEditingComplete: () =>
                            FocusScope.of(context).nextFocus(),
                      ),
                      isValidUsername.msgText != null
                          ? heightBox(8.h)
                          : Container(),
                      isValidUsername.msgText != null
                          ? Align(
                              alignment: Alignment.centerLeft,
                              child: TextWidget(
                                text: " *${isValidUsername.msgText}",
                              ))
                          : Container(),
                      heightBox(9.h),
                      SizedBox(
                        height: 156.h,
                        child: TextFormField(
                          controller: _bioController,
                          onChanged: (value) {
                            bioTxtCount = _bioController.text.length.toString();
                            editProfileScViewModel!.onNotifyListeners();
                          },
                          style: TextStyle(
                            color: color239,
                            fontSize: 16.sp,
                            fontFamily: strFontName,
                            fontWeight: FontWeight.w600,
                          ),
                          inputFormatters: [
                            LengthLimitingTextInputFormatter(100),
                          ],
                          cursorColor: color239,
                          decoration: InputDecoration(
                            filled: true,
                            fillColor: colorFF4,
                            suffixIcon: Container(
                              padding: const EdgeInsets.all(10),
                              width: 75.w,
                              alignment: Alignment.bottomRight,
                              height: constraints.minHeight,
                              child: TextWidget(
                                text: "$bioTxtCount/100",
                                fontSize: 14.sp,
                                color: color080,
                                fontWeight: FontWeight.w400,
                              ),
                            ),
                            hintText: strBio,
                            hintStyle: TextStyle(
                              color: const Color(0xFF3B3B3B).withOpacity(0.5),
                              fontSize: 16.sp,
                              fontFamily: strFontName,
                              fontWeight: FontWeight.w300,
                            ),
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(16.0),
                                borderSide: BorderSide.none),
                          ),
                          maxLines: 5,
                          onEditingComplete: () =>
                              FocusScope.of(context).unfocus(),
                        ),
                      ),
                      heightBox(9.h),
                      CustomDatePicker(
                        getDateTime: _getDateTime,
                        showSelected: showSelectedDates,
                        dateChangedCallback: (DateTime value) {
                          _getDateTime = value;
                          printLog(value.day);
                          printLog(value.month);
                          printLog(value.year);
                          _selectedDob =
                              "${value.year}-${AppUtils.instance.convertSingleToTwoDigit(value.month.toString())}-${AppUtils.instance.convertSingleToTwoDigit(value.day.toString())}";
                          printLog(_selectedDob);
                        },
                      ),
                      heightBox(20.h),
                      CommonButton(
                        height: 56.h,
                        text: strSave,
                        // showLoading: editProfileScViewModel!.isLoading,
                        onTap: () async {
                          if (await AppConstant.checkNetwork()) {
                            if (_checkValidData()) {
                              editProfileScViewModel!.onStartLoader();
                              printLog(_selectedDob.toString());
                              formData = FormData.fromMap({
                                "first_name": _firstNameController.text,
                                "last_name": _lastNameController.text,
                                "username": _userNameController.text,
                                "bio": _bioController.text,
                                "dob": _selectedDob,
                                "profile_image": imageFilePicked != null
                                    ? await MultipartFile.fromFile(
                                        imageFilePicked!.path,
                                        filename: imageFilePicked!.path
                                            .split('/')
                                            .last)
                                    : null
                              });

                              bool isSuccess = await SettingServices()
                                  .updateProfileData(formData!);
                              editProfileScViewModel!.onStopLoader();
                              isSuccess ? goBack() : null;
                            }
                          }
                        },
                        width: constraints.maxWidth,
                      ),
                    ],
                  ),
                ),
              ),
              editProfileScViewModel!.isLoading ? centerLoader() : Container()
            ],
          ),
        );
      },
    );
  }
}
