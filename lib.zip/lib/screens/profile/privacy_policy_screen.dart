import 'dart:async';
import 'dart:io';
import 'package:casarancha/api/api_urls.dart';
import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

import '../../base/base_stateful_widget.dart';
import '../../resources/localization_text_strings.dart';
import '../../utils/app_utils.dart';
import '../../widgets/common_appbar.dart';

class PrivacyPolicyScreen extends StatefulWidget {
  final int fromWhere;

  const PrivacyPolicyScreen({Key? key, required this.fromWhere}) : super(key: key);


  @override
  _PrivacyPolicyScreenState createState() => _PrivacyPolicyScreenState();
}

class _PrivacyPolicyScreenState extends BaseStatefulWidgetState<PrivacyPolicyScreen> {
  @override
  PreferredSizeWidget? buildAppBar(BuildContext context) {
    return iosBackIcAppBar(
      title: widget.fromWhere == 1 ? strPrivacyPolicy : widget.fromWhere == 2 ? strTermsCondition : strAbout,
      onTapLead: () => goBack(),
    );
  }
  final Completer<WebViewController> _controller = Completer<WebViewController>();
  _makeUrl() {
      if (widget.fromWhere == 1) {
        return ApiUrl.privacyUrl;
      } else if (widget.fromWhere == 2) {
        return ApiUrl.termsConditionUrl;
      } else if (widget.fromWhere == 3) {
        return ApiUrl.aboutUrl;
      } else {
        return ApiUrl.baseURL;
      }
    }

  @override
  void initState() {

    if (Platform.isAndroid) {
      WebView.platform = SurfaceAndroidWebView();
    }
    super.initState();
  }


  @override
  Widget buildBody(BuildContext context) {
    return WebView(
        initialUrl: _makeUrl(),

        javascriptMode: JavascriptMode.unrestricted,
        onWebViewCreated: (WebViewController webViewController) {
          _controller.complete(webViewController);
        },
        onProgress: (int progress) {
          printLog('WebView is loading (progress : $progress%)');
        },
        javascriptChannels: <JavascriptChannel>{
          _toasterJavascriptChannel(context),
        },
        onPageStarted: (String url) {
          printLog('Page started loading: $url');
        },
        onPageFinished: (String url) {
          printLog('Page finished loading: $url');
        },
        gestureNavigationEnabled: true,
        backgroundColor: const Color(0x00000000),
      );
  }

  JavascriptChannel _toasterJavascriptChannel(BuildContext context) {
    return JavascriptChannel(
        name: 'Toaster',
        onMessageReceived: (JavascriptMessage message) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(message.message)),
          );
        });
  }
}

