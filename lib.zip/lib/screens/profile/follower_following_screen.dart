import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';

import '../../base/base_stateful_widget.dart';
import '../../resources/localization_text_strings.dart';
import '../../utils/app_constants.dart';
import '../../view_models/profile_vm/follow_following_view_model.dart';
import '../../widgets/common_appbar.dart';
import '../../widgets/common_widgets.dart';

class FollowerFollowingScreen extends StatefulWidget {
   int tabIndex = 0;
   FollowerFollowingScreen({Key? key , required this.tabIndex}) : super(key: key);

  @override
  State<FollowerFollowingScreen> createState() => _FollowerFollowingScreenState();
}

class _FollowerFollowingScreenState extends  BaseStatefulWidgetState<FollowerFollowingScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  FollowFollowingViewModel? followFollowingViewModel;
  final List<Widget> _myTabs = const [
    Tab(text: strProfileFollowers),
    Tab(text: strProfileFollowing),
  ];

  @override
  void initState() {
    _tabController = TabController(vsync: this, length: _myTabs.length);
    _tabController.index = widget.tabIndex;
    // TODO: implement initState
    super.initState();
  }
  @override
  PreferredSizeWidget? buildAppBar(BuildContext context) {
    return iosBackIcAppBar(
        title: strFollowersFollowing,
        onTapLead: () => goBack(),
      );
  }

  @override
  Widget buildBody(BuildContext context) {
     followFollowingViewModel  = Provider.of<FollowFollowingViewModel>(context);
    return LayoutBuilder(
        builder: (BuildContext context, BoxConstraints constraints) {
          return ConstrainedBox(
              constraints: BoxConstraints(minHeight: constraints.minHeight),
              child:  Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 20.w),
                    child: commonTabBar(
                        tabsList: _myTabs, controller: _tabController),
                  ),
                  heightBox(15.h),
                  Expanded(
                      child: TabBarView(controller: _tabController, children: [
                        ListView.builder(
                            shrinkWrap: true,
                            physics: const BouncingScrollPhysics(),
                            itemCount: 10,
                            itemBuilder: (BuildContext context, int index) {
                              return cardProfileStrAction(

                                  strProfileImg: postProfileImg,
                                  userName: "_23 Jane ",
                                  idIsVerified: true,
                                  subTxt: "Xender Rendos",
                                  strAction: strRemove,
                                  onTapAction: () {});
                            }),
                        ListView.builder(
                            shrinkWrap: true,
                            physics: const BouncingScrollPhysics(),
                            itemCount: 10,
                            itemBuilder: (BuildContext context, int index) {
                              return cardProfileStrAction(

                                  strProfileImg: postProfileImg,
                                  userName: "_23 Jane ",
                                  idIsVerified: true,
                                  subTxt: "Xender Rendos",
                                  strAction: strSrcFollow,
                                  onTapAction: () {});
                            }),

                      ])),
                ],
              ));
        });
  }
}
