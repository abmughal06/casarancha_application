import 'package:cached_network_image/cached_network_image.dart';
import 'package:casarancha/widgets/listView_with_whereIn_querry.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';
import 'package:flutterfire_ui/firestore.dart';
import 'package:get/get.dart';

import 'package:casarancha/models/post_model.dart';
import 'package:casarancha/models/user_model.dart';
import 'package:casarancha/resources/color_resources.dart';
import 'package:casarancha/resources/image_resources.dart';
import 'package:casarancha/screens/chat/chat_profile_user_screen.dart';
import 'package:casarancha/screens/profile/follower_following_screen.dart';

import '../../resources/localization_text_strings.dart';
import '../../widgets/PostCard/PostCard.dart';
import '../../widgets/PostCard/PostCardController.dart';
import '../../widgets/common_widgets.dart';
import '../../widgets/text_widget.dart';

class AppUserScreen extends StatefulWidget {
  const AppUserScreen(
      {Key? key,
      this.appUser,
      required this.currentUserId,
      required this.appUserId})
      : super(key: key);

  final UserModel? appUser;
  final String appUserId;
  final String currentUserId;

  @override
  State<AppUserScreen> createState() => _AppUserScreenState();
}

class _AppUserScreenState extends State<AppUserScreen> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: widget.appUser == null
            ? FutureBuilder(
                future: FirebaseFirestore.instance
                    .collection('users')
                    .doc(widget.appUserId)
                    .get(),
                builder: (context, AsyncSnapshot snapshot) {
                  UserModel appUser = UserModel(
                    id: '',
                    email: '',
                    username: '',
                    dob: '',
                    name: '',
                    createdAt: '',
                    bio: '',
                    imageStr: '',
                    isOnline: false,
                  );

                  if (snapshot.hasData) {
                    appUser = UserModel.fromMap(
                      snapshot.data.data() as Map<String, dynamic>,
                    );
                  }

                  return snapshot.connectionState == ConnectionState.waiting
                      ? const Center(
                          child: CircularProgressIndicator.adaptive(),
                        )
                      : AppUserBody(
                          appUser: appUser,
                          currentUserId: widget.currentUserId,
                        );
                },
              )
            : AppUserBody(
                appUser: widget.appUser!,
                currentUserId: widget.currentUserId,
              ),
      ),
    );
  }
}

class AppUserBody extends StatefulWidget {
  const AppUserBody({
    Key? key,
    required this.appUser,
    required this.currentUserId,
  }) : super(key: key);

  final UserModel appUser;

  final String currentUserId;

  @override
  State<AppUserBody> createState() => _AppUserBodyState();
}

class _AppUserBodyState extends State<AppUserBody> {
  late bool isFollowing;

  @override
  void initState() {
    super.initState();
    isFollowing = widget.appUser.followersIds.contains(widget.currentUserId);
  }

  @override
  Widget build(BuildContext context) {
    return NestedScrollView(
      headerSliverBuilder: (context, innerBoxIsScrolled) => [
        SliverToBoxAdapter(
          child: Column(
            children: [
              Align(
                alignment: Alignment.topLeft,
                child: IconButton(
                  onPressed: () {
                    Get.back();
                  },
                  icon: const Icon(
                    Icons.keyboard_arrow_left_rounded,
                  ),
                ),
              ),
              Align(
                alignment: Alignment.center,
                child: CachedNetworkImage(
                  imageUrl: widget.appUser.imageStr,
                  imageBuilder: (context, imageProvider) => Container(
                    width: 80,
                    height: 80,
                    decoration: BoxDecoration(
                      image: DecorationImage(
                        image: imageProvider,
                        fit: BoxFit.cover,
                      ),
                      borderRadius: const BorderRadius.all(Radius.circular(50)),
                      border: Border.all(
                        color: colorPrimaryA05,
                        width: 2.w,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: colorBlack.withOpacity(.11),
                          spreadRadius: 1,
                          blurRadius: 5,
                          offset: const Offset(0, 10),
                        ),
                      ],
                    ),
                  ),
                  placeholder: (context, url) => shimmerImg(
                      child: const CircleAvatar(
                    radius: 50,
                  )),
                  errorWidget: (context, url, error) => const Icon(Icons.error),
                ),
              ),
              heightBox(15.h),
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextWidget(
                    text: widget.appUser.name,
                    color: color13F,
                    fontWeight: FontWeight.w600,
                    fontSize: 16.sp,
                  ),
                  widthBox(6.w),
                  if (widget.appUser.isVerified)
                    SvgPicture.asset(
                      icVerifyBadge,
                      width: 17.w,
                      height: 17.h,
                    )
                ],
              ),
              TextWidget(
                text: widget.appUser.username,
                color: colorAA3,
                fontSize: 12.sp,
              ),
              heightBox(12.h),
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  postFollowCount(
                      count: widget.appUser.postsIds.length.toString(),
                      strText: strProfilePost),
                  verticalLine(height: 24.h, horizontalMargin: 30.w),
                  GestureDetector(
                    onTap: () =>
                        Get.to(() => FollowerFollowingScreen(tabIndex: 0)),
                    child: postFollowCount(
                        count: widget.appUser.followersIds.length.toString(),
                        strText: strProfileFollowers),
                  ),
                  verticalLine(height: 24.h, horizontalMargin: 30.w),
                  GestureDetector(
                    onTap: () =>
                        Get.to(() => FollowerFollowingScreen(tabIndex: 1)),
                    child: postFollowCount(
                        count: widget.appUser.followingsIds.length.toString(),
                        strText: strProfileFollowing),
                  ),
                ],
              ),
              heightBox(14.h),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 27.w),
                child: TextWidget(
                  text: widget.appUser.bio,
                  textAlign: TextAlign.center,
                  color: color55F,
                  fontSize: 12.sp,
                ),
              ),
              heightBox(20.h),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 20.w),
                child: Row(
                  children: [
                    Expanded(
                      child: GestureDetector(
                        onTap: () {
                          if (isFollowing) {
                            //   FirebaseFirestore.instance
                            //       .collection('users')
                            //       .doc(widget.currentUserId)
                            //       .update({
                            //     'followingsIds':
                            //         FieldValue.arrayRemove([widget.currentUserId])
                            //   });
                            //   setState(() {
                            //     isFollowing = true;
                            //   });
                            // } else {
                            //   FirebaseFirestore.instance
                            //       .collection('users')
                            //       .doc(widget.currentUserId)
                            //       .update({
                            //     'followingsIds':
                            //         FieldValue.arrayUnion([widget.currentUserId])
                            //   });
                            //   setState(() {
                            //     isFollowing = false;
                            //   });
                          }
                        },
                        child: Container(
                          height: 45.h,
                          decoration: isFollowing
                              ? BoxDecoration(
                                  color: colorF03,
                                  borderRadius: BorderRadius.circular(12.r),
                                  boxShadow: [
                                    BoxShadow(
                                      color: colorBlack.withOpacity(.06),
                                      spreadRadius: 1,
                                      blurRadius: 5,
                                      offset: const Offset(0, 2),
                                    ),
                                    BoxShadow(
                                      color: colorBlack.withOpacity(.04),
                                      spreadRadius: 1,
                                      blurRadius: 5,
                                      offset: const Offset(0, 2),
                                    )
                                  ],
                                )
                              : BoxDecoration(
                                  color: colorWhite,
                                  border:
                                      Border.all(width: 1.w, color: color221),
                                  borderRadius: BorderRadius.circular(12.r),
                                  boxShadow: [
                                    BoxShadow(
                                      color: colorBlack.withOpacity(.06),
                                      spreadRadius: 1,
                                      blurRadius: 5,
                                      offset: const Offset(0, 2),
                                    ),
                                    BoxShadow(
                                      color: colorBlack.withOpacity(.04),
                                      spreadRadius: 1,
                                      blurRadius: 5,
                                      offset: const Offset(0, 2),
                                    )
                                  ],
                                ),
                          child: Center(
                            child: TextWidget(
                              text: !isFollowing ? strSrcFollow : strUnFollow,
                              color: color13F,
                              fontSize: 18.sp,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ),
                    ),
                    widthBox(15.w),
                    GestureDetector(
                      onTap: () => Get.to(() => ChatProfileUserScreen()),
                      child: Image.asset(
                        imgProMsg,
                        height: 45.h,
                        width: 45.w,
                      ),
                    )
                  ],
                ),
              ),
            ],
          ),
        )
      ],
      body: DefaultTabController(
        length: 2,
        child: Column(
          children: [
            // ),
            commonTabBar(
              tabsList: const [
                Tab(
                  child: Text('Posts'),
                ),
                Tab(
                  child: Text('Stories'),
                ),
              ],
            ),
            heightBox(10.w),
            Expanded(
              child: TabBarView(
                children: [
                  ListViewPostsWithWhereInQuerry(
                    listOfIds: widget.appUser.postsIds,
                    controllerTag: widget.appUser.id,
                  ),
                  const Center()
                ],
              ),
            )
          ],
        ),
      ),
    );
  }

  Widget postFollowCount({required String count, required String strText}) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        TextWidget(
          text: count,
          color: color13F,
          fontWeight: FontWeight.w500,
          fontSize: 16.sp,
        ),
        heightBox(3.h),
        TextWidget(
          text: strText,
          color: colorAA3,
          fontWeight: FontWeight.w500,
          fontSize: 12.sp,
        ),
      ],
    );
  }
}
