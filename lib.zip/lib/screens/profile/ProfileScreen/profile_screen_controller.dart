import 'package:casarancha/models/user_model.dart';
import 'package:casarancha/utils/snackbar.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

import 'package:get/get.dart';

class ProfileScreenController extends SuperController {
  final firebaseAuth = FirebaseAuth.instance;
  final fbfirestore = FirebaseFirestore.instance;
  //Obserables
  var user = UserModel(
    id: '',
    email: '',
    username: '',
    dob: '',
    name: '',
    createdAt: '',
    bio: '',
    imageStr: '',
    isOnline: false,
  ).obs;

  var isGettingUserData = false.obs;

  //Methods
  Future<void> getUser() async {
    isGettingUserData.value = true;
    final userId = firebaseAuth.currentUser!.uid;
    final userRef = fbfirestore.collection('users').doc(userId);
    try {
      final userData = await userRef.get();
      user.value = UserModel.fromMap(userData.data() as Map<String, dynamic>);
    } catch (e) {
      GlobalSnackBar.show(message: e.toString());
    }
    isGettingUserData.value = false;
  }

  Future<void> logout() async {
    await Get.deleteAll();
    try {
      await FirebaseAuth.instance.signOut();
    } catch (e) {
      GlobalSnackBar.show(message: e.toString());
    }
    Get.back(
      closeOverlays: true,
    );
  }

  //Overrides
  @override
  void onInit() async {
    await getUser();
    print(user.value.id);
    fbfirestore.doc(user.value.id).update({
      'isOnline': true,
    });
    super.onInit();
  }

  @override
  void onDetached() {
    print('detched');

    fbfirestore.doc(user.value.id).update({
      'isOnline': false,
    });
  }

  @override
  void onInactive() {
    print('inactive');

    fbfirestore.doc(user.value.id).update({
      'isOnline': false,
    });
  }

  @override
  void onPaused() {
    print('puased');
    fbfirestore.doc(user.value.id).update({
      'isOnline': false,
    });
  }

  @override
  void onResumed() {
    print('resumed');

    fbfirestore.doc(user.value.id).update({
      'isOnline': true,
    });
  }
}
