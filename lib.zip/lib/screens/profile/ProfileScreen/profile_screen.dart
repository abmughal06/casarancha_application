import 'package:cached_network_image/cached_network_image.dart';
import 'package:casarancha/models/post_model.dart';
import 'package:casarancha/resources/color_resources.dart';
import 'package:casarancha/resources/image_resources.dart';
import 'package:casarancha/screens/auth/setup_profile_details.dart';
import 'package:casarancha/screens/profile/ProfileScreen/profile_screen_controller.dart';
import 'package:casarancha/screens/profile/privacy_policy_screen.dart';
import 'package:casarancha/screens/profile/saved_post_screen.dart';
import 'package:casarancha/screens/profile/settings_screen.dart';
import 'package:casarancha/utils/snackbar.dart';
import 'package:casarancha/view_models/profile_vm/profile_screen_view_model.dart';
import 'package:casarancha/widgets/PostCard/PostCard.dart';
import 'package:casarancha/widgets/PostCard/PostCardController.dart';
import 'package:casarancha/widgets/common_appbar.dart';
import 'package:casarancha/widgets/listView_with_whereIn_querry.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';
import 'package:flutterfire_ui/firestore.dart';
import 'package:get/get.dart';
import 'package:provider/provider.dart';

import '../../../base/base_stateful_widget.dart';
import '../../../resources/localization_text_strings.dart';
import '../../../serivces/profile_services/profile_bottom_sheet_services.dart';
import '../../../utils/app_constants.dart';
import '../../../utils/shared_preference_util.dart';

import '../../../widgets/common_widgets.dart';
import '../../../widgets/home_page_widgets.dart';
import '../../../widgets/text_widget.dart';
import '../../auth/login_screen.dart';
import '../../home/view_post_screen.dart';
import '../edit_profile_screen.dart';
import '../follower_following_screen.dart';

class ProfileScreen extends StatelessWidget {
  ProfileScreen({Key? key}) : super(key: key);
  final ProfileScreenController profileScreenController =
      Get.find<ProfileScreenController>();

  Widget postFollowCount({required String count, required String strText}) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        TextWidget(
          text: count,
          color: color13F,
          fontWeight: FontWeight.w500,
          fontSize: 16.sp,
        ),
        heightBox(3.h),
        TextWidget(
          text: strText,
          color: colorAA3,
          fontWeight: FontWeight.w500,
          fontSize: 12.sp,
        ),
      ],
    );
  }

  Widget postStoriesBtn(
      {required String icon, required String text, required bool isSelected}) {
    return Expanded(
      child: SizedBox(
        height: 47.h,
        child: Center(
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SvgPicture.asset(icon),
              widthBox(12.w),
              TextWidget(
                text: text,
                color: isSelected ? colorPrimaryA05 : colorAA3,
                fontSize: 14.sp,
              ),
            ],
          ),
        ),
      ),
    );
  }

  _bottomSheetProfile(context) {
    showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        backgroundColor: Colors.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
              topLeft: Radius.circular(40.r), topRight: Radius.circular(40.r)),
        ),
        builder: (BuildContext context) {
          return Container(
              height: 500,
              padding: EdgeInsets.symmetric(horizontal: 24.w),
              child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  // mainAxisSize: MainAxisSize.min,
                  children: [
                    heightBox(10.h),
                    Align(
                      alignment: Alignment.center,
                      child: Container(
                        height: 6.h,
                        width: 78.w,
                        decoration: BoxDecoration(
                          color: colorDD9,
                          borderRadius: BorderRadius.all(Radius.circular(30.r)),
                        ),
                      ),
                    ),
                    heightBox(10.h),
                    Expanded(
                      child: ListView.builder(
                          itemCount: AppConstant.profileBottomSheetList.length,
                          itemBuilder: (context, index) {
                            return Padding(
                              padding:
                                  const EdgeInsets.symmetric(vertical: 14.0),
                              child: textMenuItem(
                                  text:
                                      AppConstant.profileBottomSheetList[index],
                                  color: AppConstant.profileBottomSheetList
                                                  .length -
                                              1 ==
                                          index
                                      ? Colors.red
                                      : null,
                                  onTap: () {
                                    _onTapSheetItem(index: index);
                                  }),
                            );
                          }),
                    )
                  ]));
        });
  }

  _onTapSheetItem({required int index}) async {
    switch (index) {
      case 0:
        // Get.to(() => const SetupProfileScreen());
        break;
      case 1:
        Get.to(() => SavedPostScreen());
        break;
      case 2:
        //getVerify
        break;
      case 3:

      case 4:
        //about

        break;
      case 5:
        //terms

        break;
      case 6:
        //privacy

        break;
      case 7:
        //logout
        profileScreenController.logout();

        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: NestedScrollView(
          headerSliverBuilder: (context, innerBoxIsScrolled) => [
            SliverToBoxAdapter(
              child: Column(
                children: [
                  Align(
                    alignment: Alignment.topRight,
                    child: IconButton(
                      onPressed: () {
                        _bottomSheetProfile(context);
                      },
                      icon: Image.asset(
                        imgProfileOption,
                        height: 35.h,
                        width: 35.w,
                      ),
                    ),
                  ),
                  Align(
                    alignment: Alignment.center,
                    child: CachedNetworkImage(
                      imageUrl: profileScreenController.user.value.imageStr,
                      imageBuilder: (context, imageProvider) => Container(
                        width: 80,
                        height: 80,
                        decoration: BoxDecoration(
                          image: DecorationImage(
                            image: imageProvider,
                            fit: BoxFit.cover,
                          ),
                          borderRadius:
                              const BorderRadius.all(Radius.circular(50)),
                          border: Border.all(
                            color: colorPrimaryA05,
                            width: 2.w,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: colorBlack.withOpacity(.11),
                              spreadRadius: 1,
                              blurRadius: 5,
                              offset: const Offset(0, 10),
                            ),
                          ],
                        ),
                      ),
                      placeholder: (context, url) => shimmerImg(
                          child: const CircleAvatar(
                        radius: 50,
                      )),
                      errorWidget: (context, url, error) =>
                          const Icon(Icons.error),
                    ),
                  ),
                  heightBox(15.h),
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      TextWidget(
                        text: profileScreenController.user.value.name,
                        color: color13F,
                        fontWeight: FontWeight.w600,
                        fontSize: 16.sp,
                      ),
                      widthBox(6.w),
                      if (profileScreenController.user.value.isVerified)
                        SvgPicture.asset(
                          icVerifyBadge,
                          width: 17.w,
                          height: 17.h,
                        )
                    ],
                  ),
                  TextWidget(
                    text: profileScreenController.user.value.username,
                    color: colorAA3,
                    fontSize: 12.sp,
                  ),
                  heightBox(12.h),
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      postFollowCount(
                          count: profileScreenController
                              .user.value.postsIds.length
                              .toString(),
                          strText: strProfilePost),
                      verticalLine(height: 24.h, horizontalMargin: 30.w),
                      GestureDetector(
                        onTap: () =>
                            Get.to(() => FollowerFollowingScreen(tabIndex: 0)),
                        child: postFollowCount(
                            count: profileScreenController
                                .user.value.followersIds.length
                                .toString(),
                            strText: strProfileFollowers),
                      ),
                      verticalLine(height: 24.h, horizontalMargin: 30.w),
                      GestureDetector(
                        onTap: () =>
                            Get.to(() => FollowerFollowingScreen(tabIndex: 1)),
                        child: postFollowCount(
                            count: profileScreenController
                                .user.value.followingsIds.length
                                .toString(),
                            strText: strProfileFollowing),
                      ),
                    ],
                  ),
                  heightBox(14.h),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 27.w),
                    child: TextWidget(
                      text: profileScreenController.user.value.bio,
                      textAlign: TextAlign.center,
                      color: color55F,
                      fontSize: 12.sp,
                    ),
                  ),
                  heightBox(20.h),
                ],
              ),
            )
          ],
          body: DefaultTabController(
            length: 2,
            child: Column(
              children: [
                commonTabBar(
                  tabsList: const [
                    Tab(
                      child: Text('Posts'),
                    ),
                    Tab(
                      child: Text('Stories'),
                    ),
                  ],
                ),
                heightBox(10.w),
                Expanded(
                  child: TabBarView(
                    children: [
                      ListViewPostsWithWhereInQuerry(
                        listOfIds: profileScreenController.user.value.postsIds,
                        controllerTag: 'Profile Posts',
                      ),
                      const Center()
                    ],
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
