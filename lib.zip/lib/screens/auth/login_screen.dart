import 'dart:io';

import 'package:casarancha/screens/auth/setup_profile_details.dart';
import 'package:casarancha/screens/auth/sign_up_screen.dart';
import 'package:casarancha/screens/dashboard/dashboard.dart';
import 'package:casarancha/screens/home/HomeScreen/home_screen.dart';

import 'package:casarancha/utils/app_constants.dart';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:email_validator/email_validator.dart';
import 'package:firebase_auth/firebase_auth.dart';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';

import '../../base/base_stateful_widget.dart';

import '../../resources/color_resources.dart';
import '../../resources/image_resources.dart';
import '../../resources/localization_text_strings.dart';

import '../../utils/snackbar.dart';

import '../../widgets/common_button.dart';
import '../../widgets/common_widgets.dart';
import '../../widgets/text_editing_widget.dart';
import '../../widgets/text_widget.dart';

import 'forgot_password_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  bool isSigningIn = false;

  bool passwordVisible = true;
  FocusNode emailFocus = FocusNode();
  FocusNode passwordFocus = FocusNode();
  String? icEmailSvg, icPasswordSvg;
  Color? emailFillClr, passwordFillClr, emailBorderClr, passwordBorderClr;

  setPwdVisibility() {
    passwordVisible = !passwordVisible;
    icPasswordSvg == icShowPassword
        ? icPasswordSvg = icHidePassword
        : icPasswordSvg = icShowPassword;
    setState(() {});
  }

  onFieldFocusChange() {
    setState(() {});
  }

  setEmailFocusChange() {
    if (emailFocus.hasFocus) {
      icEmailSvg = icSelectEmail;
      emailFillClr = colorFDF;
      emailBorderClr = colorF73;
    } else {
      icEmailSvg = icDeselectEmail;
      emailFillClr = colorFF3;
      emailBorderClr = null;
    }
    setState(() {});
  }

  setPwdFocusChange() {
    if (passwordFocus.hasFocus) {
      // icPasswordSvg = icSelectLock;
      passwordFillClr = colorFDF;
      passwordBorderClr = colorF73;
    } else {
      // icPasswordSvg = icDeselectLock;
      passwordFillClr = colorFF3;
      passwordBorderClr = null;
    }

    setState(() {});
  }

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  bool _checkValidData() {
    if (_emailController.text.isEmpty) {
      GlobalSnackBar.show(
          context: context, message: 'Please enter $strEmailAddress');
      return false;
    } else if (!EmailValidator.validate(_emailController.text.trim())) {
      GlobalSnackBar.show(
          context: context, message: 'Please enter valid $strEmailAddress');
      return false;
    } else if (_passwordController.text.isEmpty) {
      GlobalSnackBar.show(
          context: context, message: 'Please enter $strPassword');
      return false;
    }
    return true;
  }

  void _emailFocusChange(BuildContext context) {
    setEmailFocusChange();
  }

  void _pwdFocusChange(BuildContext context) {
    setPwdFocusChange();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          AspectRatio(
            aspectRatio: 16 / 9,
            child: Image.asset(
              imgSignBack,
              fit: BoxFit.cover,
            ),
          ),
          Expanded(
            child: ListView(
              padding: EdgeInsets.all(
                20.w,
              ),
              children: [
                Align(
                  alignment: Alignment.centerLeft,
                  child: TextWidget(
                    text: strWelcome,
                    fontSize: 26.sp,
                    color: color13F,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                heightBox(8.h),
                Align(
                  alignment: Alignment.centerLeft,
                  child: TextWidget(
                    text: strPleaseSignInYouAccount,
                    fontSize: 16.sp,
                    color: color080,
                    fontWeight: FontWeight.w400,
                  ),
                ),
                heightBox(30.h),
                Focus(
                  focusNode: emailFocus,
                  onFocusChange: (hasFocus) {
                    _emailFocusChange(context);
                  },
                  child: TextEditingWidget(
                    controller: _emailController,
                    hint: strEmailAddress,
                    color: emailFillClr ?? colorFF3,
                    fieldBorderClr: emailBorderClr,
                    textInputType: TextInputType.emailAddress,
                    textInputAction: TextInputAction.next,
                    onFieldSubmitted: (val) =>
                        FocusScope.of(context).nextFocus(),
                    onEditingComplete: () => FocusScope.of(context).nextFocus(),
                    suffixIconWidget: Padding(
                      padding: EdgeInsets.symmetric(horizontal: 10.w),
                      child: SvgPicture.asset(icEmailSvg ?? icDeselectEmail),
                    ),
                  ),
                ),
                heightBox(16.h),
                Focus(
                  focusNode: passwordFocus,
                  onFocusChange: (hasFocus) {
                    _pwdFocusChange(context);
                  },
                  child: TextEditingWidget(
                    controller: _passwordController,
                    hint: strPassword,
                    fieldBorderClr: passwordBorderClr,
                    textInputType: TextInputType.visiblePassword,
                    textInputAction: TextInputAction.done,
                    // onFieldSubmitted: (str) =>
                    //     push(context, enterPage: const SignUpScreen()),
                    passwordVisible: passwordVisible,
                    color: passwordFillClr ?? colorFF3,
                    onEditingComplete: () => FocusScope.of(context).unfocus(),
                    suffixIconWidget: Padding(
                      padding: EdgeInsets.symmetric(horizontal: 10.w),
                      child: GestureDetector(
                        onTap: () => setPwdVisibility(),
                        child: SvgPicture.asset(
                          icPasswordSvg ?? icHidePassword,
                        ),
                      ),
                    ),
                  ),
                ),
                heightBox(24.h),
                Align(
                  alignment: Alignment.center,
                  child: GestureDetector(
                    onTap: () => Get.to(
                      () => const ForgotPasswordScreen(),
                    ),
                    child: TextWidget(
                      text: strForgotPassword,
                      fontSize: 14.sp,
                      color: color080,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                ),
                heightBox(24.h),
                CommonButton(
                  showLoading: isSigningIn,
                  onTap: () async {
                    // push(context, enterPage: const SetProfileScreen());
                    if (await AppConstant.checkNetwork()) {
                      if (_checkValidData()) {
                        setState(() {
                          isSigningIn = true;
                        });

                        try {
                          final userData = await FirebaseAuth.instance
                              .signInWithEmailAndPassword(
                            email: _emailController.text.trim(),
                            password: _passwordController.text.trim(),
                          );

                          final currentUserId = userData.user?.uid ?? '';

                          final userRef = await FirebaseFirestore.instance
                              .collection('users')
                              .doc(currentUserId)
                              .get();

                          if (userRef.exists) {
                            Get.off(() => DashBoard());
                          } else {
                            Get.off(() => const SetupProfileScreen());
                          }
                        } catch (e) {
                          GlobalSnackBar.show(
                            context: context,
                            message: e.toString(),
                          );
                          setState(() {
                            isSigningIn = false;
                          });
                        }
                      }
                    }
                  },
                  text: strSignInSp,
                  width: double.infinity,
                ),
                heightBox(26.h),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    horizonLine(width: 80.w, horizontalMargin: 18.w),
                    TextWidget(
                      text: strWith,
                      fontSize: 14.sp,
                      color: color080,
                      fontWeight: FontWeight.w500,
                    ),
                    horizonLine(
                      width: 80.w,
                      horizontalMargin: 18.w,
                    ),
                  ],
                ),
                heightBox(26.h),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 12.w),
                      child: Image.asset(
                        imgGoogleSignIn,
                        scale: 3,
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 12.w),
                      child: svgImgButton(
                        svgIcon: imgTwitterSignIn,
                      ),
                    ),
                    Platform.isIOS
                        ? Padding(
                            padding: EdgeInsets.symmetric(horizontal: 12.w),
                            child: svgImgButton(
                              svgIcon: imgAppleSignIn,
                            ),
                          )
                        : Container(),
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 12.w),
                      child: svgImgButton(
                        svgIcon: imgFaceBookSignIn,
                      ),
                    ),
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    TextWidget(
                      text: strYouDontHaveAccount,
                      fontSize: 12.sp,
                      color: color080,
                      fontWeight: FontWeight.w500,
                    ),
                    widthBox(4.w),
                    TextWidget(
                      onTap: () => Get.to(() => const SignUpScreen()),
                      text: strSignUp,
                      fontSize: 12.sp,
                      color: color13F,
                      fontWeight: FontWeight.w600,
                    ),
                  ],
                ),
                Align(
                  alignment: Alignment.center,
                  child: TextWidget(
                    onTap: () {},
                    text: strRexFamily,
                    fontSize: 14.sp,
                    color: colorPrimaryA05,
                    fontWeight: FontWeight.w400,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
