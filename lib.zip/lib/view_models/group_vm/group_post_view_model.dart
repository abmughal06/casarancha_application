
import '../common_card_post_vm.dart';

class GroupPostViewModel extends CommonCardPostVm{

}