import '../common_card_post_vm.dart';

class SavedPostViewModel extends CommonCardPostVm{

}