import '../common_card_post_vm.dart';

class ProfileScreenViewModel extends CommonCardPostVm{

}