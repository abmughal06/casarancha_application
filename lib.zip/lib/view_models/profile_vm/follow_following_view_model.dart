
import '../common_card_post_vm.dart';

class FollowFollowingViewModel extends CommonCardPostVm{

}