import 'package:flutter/material.dart';

import '../resources/color_resources.dart';
import '../resources/image_resources.dart';
import 'common_view_model.dart';

class SignupScreenViewModel extends CommonViewModel {}
