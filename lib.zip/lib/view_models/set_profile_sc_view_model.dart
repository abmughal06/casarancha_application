import 'package:casarancha/view_models/common_view_model.dart';

class SetProfileScViewModel  extends CommonViewModel{

}