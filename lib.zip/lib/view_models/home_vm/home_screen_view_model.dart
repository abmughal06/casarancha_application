import 'package:flutter/material.dart';

import '../../models/post_model.dart';
import '../../models/home_page/share_with_user.dart';
import '../../utils/app_constants.dart';
import '../../utils/app_utils.dart';
import '../common_card_post_vm.dart';

class HomeScreenViewModel extends CommonCardPostVm {
  ScrollController scrollController = ScrollController();
  List<PostModel> feedPostList = [];
  bool isLikedPost = false;
  String? notifyCount = "12";

  List<ShareWithUser> userList = [
    ShareWithUser(
      isSelectShare: false,
      imgUrl: imgNavBarUser,
      isVerify: true,
      subName: 'Joann',
      userName: 'Joann123',
    ),
    ShareWithUser(
      isSelectShare: false,
      imgUrl: imgNavBarUser,
      isVerify: false,
      subName: 'grhttyj',
      userName: 'sdfsdf',
    ),
    ShareWithUser(
      isSelectShare: false,
      imgUrl: imgNavBarUser,
      isVerify: true,
      subName: 'Joann',
      userName: 'regrgg',
    ),
    ShareWithUser(
      isSelectShare: true,
      imgUrl: imgNavBarUser,
      isVerify: false,
      subName: 'frfrgt',
      userName: 'sdfsdre',
    ),
    ShareWithUser(
      isSelectShare: true,
      imgUrl: imgNavBarUser,
      isVerify: true,
      subName: 'Joann',
      userName: 'Joann123',
    ),
    ShareWithUser(
      isSelectShare: false,
      imgUrl: imgNavBarUser,
      isVerify: false,
      subName: 'jytht',
      userName: 'vdfveg',
    ),
    ShareWithUser(
      isSelectShare: true,
      imgUrl: imgNavBarUser,
      isVerify: true,
      subName: 'tretg',
      userName: 'frgergt',
    ),
    ShareWithUser(
      isSelectShare: false,
      imgUrl: imgNavBarUser,
      isVerify: false,
      subName: 'Joann',
      userName: 'rtr',
    ),
  ];
  bool isShareWithFrd = true;

  onTapSendUser({required int index}) {
    userList[index].isSelectShare = !userList[index].isSelectShare;

    printLog("tap on $index ${userList[index].isSelectShare}");

    notifyListeners();
  }

  onTapShareWithFrdTxt() {
    isShareWithFrd = true;
    notifyListeners();
  }

  onTapShareWithSocialTxt() {
    isShareWithFrd = false;
    notifyListeners();
  }
}
