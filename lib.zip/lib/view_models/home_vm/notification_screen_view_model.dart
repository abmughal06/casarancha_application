import 'package:flutter/material.dart';
class NotificationScreenViewModel extends ChangeNotifier{

}