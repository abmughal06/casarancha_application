import 'package:flutter/material.dart';

class NewPostShareVM extends ChangeNotifier {
  TextEditingController captionController = TextEditingController();
  TextEditingController tagPeopleController = TextEditingController();
  TextEditingController locationController = TextEditingController();
}
