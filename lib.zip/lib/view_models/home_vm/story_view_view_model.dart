import 'package:flutter/material.dart';

class StoryViewViewModel extends ChangeNotifier{

}