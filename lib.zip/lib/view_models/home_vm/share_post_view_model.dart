import 'package:flutter/material.dart';
import '../../models/home_page/share_with_user.dart';
import '../../utils/app_constants.dart';
import '../../utils/app_utils.dart';

class SharePostViewModel extends ChangeNotifier {

  List<ShareWithUser> userList = [
    ShareWithUser(isSelectShare : false,
      imgUrl: imgNavBarUser, isVerify: true, subName: 'Joann', userName: 'Joann123',),
    ShareWithUser(isSelectShare : false,
      imgUrl: imgNavBarUser, isVerify: false, subName: 'grhttyj', userName: 'sdfsdf',),
    ShareWithUser(isSelectShare : false,
      imgUrl: imgNavBarUser, isVerify: true, subName: 'Joann', userName: 'regrgg',),
    ShareWithUser(isSelectShare : false,
      imgUrl: imgNavBarUser, isVerify: false, subName: 'frfrgt', userName: 'sdfsdre',),
    ShareWithUser(isSelectShare : false,
      imgUrl: imgNavBarUser, isVerify: true, subName: 'Joann', userName: 'Joann123',),
    ShareWithUser(isSelectShare : false,
      imgUrl: imgNavBarUser, isVerify: false, subName: 'jytht', userName: 'vdfveg',),
    ShareWithUser(isSelectShare : false,
      imgUrl: imgNavBarUser, isVerify: true, subName: 'tretg', userName: 'frgergt',),
    ShareWithUser(isSelectShare : false,
      imgUrl: imgNavBarUser, isVerify: false, subName: 'Joann', userName: 'rtr',),
    ShareWithUser(isSelectShare : false,
      imgUrl: imgNavBarUser, isVerify: false, subName: 'Joann', userName: 'rtr',),    ShareWithUser(isSelectShare : false,
      imgUrl: imgNavBarUser, isVerify: false, subName: 'Joann', userName: 'rtr',),    ShareWithUser(isSelectShare : false,
      imgUrl: imgNavBarUser, isVerify: false, subName: 'Joann', userName: 'rtr',),    ShareWithUser(isSelectShare : false,
      imgUrl: imgNavBarUser, isVerify: false, subName: 'Joann', userName: 'rtr',),    ShareWithUser(isSelectShare : false,
      imgUrl: imgNavBarUser, isVerify: false, subName: 'Joann', userName: 'rtr',),    ShareWithUser(isSelectShare : false,
      imgUrl: imgNavBarUser, isVerify: false, subName: 'Joann', userName: 'rtr',),    ShareWithUser(isSelectShare : false,
      imgUrl: imgNavBarUser, isVerify: false, subName: 'Joann', userName: 'rtr',),    ShareWithUser(isSelectShare : false,
      imgUrl: imgNavBarUser, isVerify: false, subName: 'Joann', userName: 'rtr',),    ShareWithUser(isSelectShare : false,
      imgUrl: imgNavBarUser, isVerify: false, subName: 'Joann', userName: 'rtr',),    ShareWithUser(isSelectShare : false,
      imgUrl: imgNavBarUser, isVerify: false, subName: 'Joann', userName: 'rtr',),    ShareWithUser(isSelectShare : false,
      imgUrl: imgNavBarUser, isVerify: false, subName: 'Joann', userName: 'rtr',),    ShareWithUser(isSelectShare : false,
      imgUrl: imgNavBarUser, isVerify: false, subName: 'Joann', userName: 'rtr',),    ShareWithUser(isSelectShare : false,
      imgUrl: imgNavBarUser, isVerify: false, subName: 'Joann', userName: 'rtr',),

  ];
  bool isShareWithFrd = true;

  onTapSendUser({required int index}) {
    printLog("tap on $index" );
    userList[index].isSelectShare = !userList[index].isSelectShare;
    notifyListeners();
  }

  onTapShareWithFrdTxt() {

    isShareWithFrd = true;
    notifyListeners();
  }

  onTapShareWithSocialTxt() {

    isShareWithFrd = false;
    notifyListeners();
  }
}
