import 'dart:async';

import 'package:casarancha/base/base_stateful_widget.dart';
import 'package:casarancha/resources/color_resources.dart';
import 'package:casarancha/resources/image_resources.dart';
import 'package:casarancha/resources/localization_text_strings.dart';
import 'package:casarancha/screens/auth/login_screen.dart';
import 'package:casarancha/screens/home/HomeScreen/home_screen.dart';
import 'package:casarancha/utils/app_constants.dart';
import 'package:casarancha/utils/shared_preference_util.dart';
import 'package:casarancha/utils/snackbar.dart';
import 'package:casarancha/widgets/text_widget.dart';
import 'package:casarancha/widgets/version_dialog.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:internet_connection_checker/internet_connection_checker.dart';
import 'package:url_launcher/url_launcher_string.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends BaseStatefulWidgetState<SplashScreen> {
  late StreamSubscription subscription;
  bool isAlertSet = false, isDeviceConnected = false;

  @override
  void initState() {
    // TODO: implement initState
    _checkVersion();
    super.initState();
  }

  _checkVersion() async {
    subscription = Connectivity().onConnectivityChanged.listen(
      (ConnectivityResult result) async {
        isDeviceConnected = await InternetConnectionChecker().hasConnection;
        if (isDeviceConnected) {
          isAlertSet = true;
          Response? appVersionCheckRes =
              await VersionDialog().versionCheckApi();
          appVersionCheckRes != null
              ? appVersionCheckRes.statusCode == 412
                  ? openVersionDialog(appVersionCheckRes)
                  : _redirectScreen()
              : _redirectScreen();
        } else {
          GlobalSnackBar.show(message: strNoInternet);
        }
      },
    );
  }

  _redirectScreen() {
    bool isLoggedIn = SharedPreferenceUtil.getBool(AppConstant.isLoggedInPre);
    Timer(
        const Duration(seconds: 2),
        () => pushReplacement(rootScaffoldKey.currentContext!,
            enterPage: isLoggedIn ? HomeScreen() : const LoginScreen()));
  }

  openVersionDialog(appVersionCheckRes) {
    String? responseMsg = appVersionCheckRes?.data['message'],
        isForce = appVersionCheckRes?.data['data']['is_force_update'];
    showDialog(
        context: context,
        barrierDismissible: false,
        builder: (BuildContext context) => WillPopScope(
              onWillPop: () async => false,
              child: CupertinoAlertDialog(
                title: TextWidget(
                  text: strUpdate,
                  color: colorBlack,
                  fontSize: 20.sp,
                ),
                content: TextWidget(
                  text: responseMsg,
                  color: colorBlack,
                ),
                actions: <Widget>[
                  isForce != '1'
                      ? CupertinoDialogAction(
                          child: TextWidget(
                            text: strCancel,
                            color: colorBlack,
                          ),
                          onPressed: () {
                            Navigator.of(context).pop();
                            _redirectScreen();
                          },
                        )
                      : Container(),
                  CupertinoDialogAction(
                    child: TextWidget(
                      text: strUpdate,
                      color: colorBlack,
                    ),
                    onPressed: _goToPlayStore,
                  )
                ],
              ),
            ));
  }

  _goToPlayStore() {
    try {
      launchUrlString("market://details?id=" + AppConstant.appPackageName);
    } on PlatformException catch (e) {
      launchUrlString("https://play.google.com/store/apps/details?id=" +
          AppConstant.appPackageName);
    } finally {
      launchUrlString("https://play.google.com/store/apps/details?id=" +
          AppConstant.appPackageName);
    }
  }

  @override
  void dispose() {
    subscription.cancel();
    super.dispose();
  }

  @override
  Widget buildBody(BuildContext context) {
    return LayoutBuilder(
        builder: (BuildContext context, BoxConstraints constraints) {
      return ConstrainedBox(
        constraints: BoxConstraints(minHeight: constraints.minHeight),
        child: Image(
          image: const AssetImage(imgSplash),
          fit: BoxFit.fitHeight,
          height: constraints.maxHeight,
          width: constraints.maxWidth,
          alignment: Alignment.center,
        ),
      );
    });
  }
}
