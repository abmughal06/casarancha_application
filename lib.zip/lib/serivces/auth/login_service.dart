import 'dart:convert';
import 'dart:developer';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';

import '../../api/api_service.dart';
import '../../api/api_urls.dart';
import '../../models/auth/signup_model.dart';
import '../../utils/app_constants.dart';
import '../../utils/app_utils.dart';
import '../../utils/shared_preference_util.dart';
import '../../utils/snackbar.dart';

class LoginService {
  Future<SignupResponseModel?> postLogin(Map<String, dynamic> map) async {
    try {
      final response = await ApiService().dio.post(
            ApiUrl.loginUrl,
            data: map,
            options: Options(
              headers: {
                'Content-Type': 'application/json',
              },
            ),
          );
      if (response.statusCode == 200) {
        var responseJson = SignupResponseModel.fromJson(response.data['data']);
        SharedPreferenceUtil.putString(AppConstant.signupResponsePre, jsonEncode(responseJson));
        SharedPreferenceUtil.putString(
            AppConstant.userTokenPre, responseJson.token);
        SharedPreferenceUtil.putInt(
            AppConstant.profileIdPre, response.data['data']['id']);

        return responseJson;
      } else if (response.statusCode == 412) {
        GlobalSnackBar.show(message: response.data['message'].toString());
        return null;
      }
      printLog(response.data);
    } catch (e) {
      AppConstant.globalToast("Something wrong");
      debugPrint(e.toString());
    }
    return null;
  }

  Future<String?> verifyOtpReq(Map<String, dynamic> map) async {
    try {
      final response = await ApiService().dio.post(
            ApiUrl.verifyOtpUrl,
            data: map,
            options: Options(
              headers: {'Content-Type': 'application/json'},
            ),
          );
      log(response.data.toString());
      if (response.statusCode == 200) {
        return response.data['data']['reset_token'];
      } else if (response.statusCode == 412) {
        GlobalSnackBar.show(message: response.data['message'].toString());
      }
      printLog(response.data);
    } catch (e) {
      GlobalSnackBar.show(message: "Something wrong");
      debugPrint(e.toString());
    }
    return null;
  }

  Future<bool> changePassword(Map<String, dynamic> map) async {
  bool isSuccess = false;
    try {
      final response = await ApiService().dio.post(
        ApiUrl.resetPasswordUrl,
        data: map,
        options: Options(
          headers: {'Content-Type': 'application/json'},
        ),
      );
      log(response.data.toString());
      if (response.statusCode == 200) {
        return true;
      } else if (response.statusCode == 412) {
        GlobalSnackBar.show(message: response.data['message'].toString());
      }
      printLog(response.data);
    } catch (e) {
      GlobalSnackBar.show(message: "Something wrong");
      debugPrint(e.toString());
    }
    return isSuccess;
  }

}
