import 'dart:convert';
import 'dart:developer';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';

import '../../api/api_service.dart';
import '../../api/api_urls.dart';
import '../../models/auth/signup_model.dart';
import '../../utils/app_constants.dart';
import '../../utils/app_utils.dart';
import '../../utils/shared_preference_util.dart';
import '../../utils/snackbar.dart';

class SignupService {
  Future<bool> sendOtpApiReq(
      {required SignUpRequestModel signUpRequestModel, bool? isOtpForSignup}) async {
    bool isSuccess = false;
    printLog(signUpRequestModel.toJson());

    try {
      final response = await ApiService().dio.post(
            ApiUrl.sendOtpUrl,
            data: {"email": signUpRequestModel.email},
            options: Options(
              headers: {'Content-Type': 'application/json'},
            ),
          );
      log(response.data.toString());
      if (response.statusCode == 200) {
        isSuccess = true;
        AppConstant.globalToast(response.data['message'].toString());
        if(isOtpForSignup ?? false){
          SharedPreferenceUtil.putString(
              AppConstant.userEmailSignUpPre, signUpRequestModel.email);
          SharedPreferenceUtil.putString(
              AppConstant.userNameSignUpPre, signUpRequestModel.username);
          SharedPreferenceUtil.putString(
              AppConstant.userDobSignUpPre, signUpRequestModel.dob);
          SharedPreferenceUtil.putString(
              AppConstant.userPasswordSignUpPre, signUpRequestModel.password);
        }
      } else if (response.statusCode == 412) {
        GlobalSnackBar.show(message: response.data['message'].toString());
      }
      printLog(response.data);
    } catch (e) {
      GlobalSnackBar.show(message: "Something wrong");
       debugPrint(e.toString());
    }
    return isSuccess;
  }

  Future<SignupResponseModel?> signupApiReq(
      SignUpRequestModel signUpRequestModel) async {
    printLog(signUpRequestModel.toJson());
    try {
      final response = await ApiService().dio.post(
            ApiUrl.signUpUrl,
            data: signUpRequestModel.toJson(),
            options: Options(
              headers: {'Content-Type': 'application/json'},
            ),
          );
      if (response.statusCode == 200) {
        AppConstant.globalToast(response.data['message'].toString());
        var responseJson = SignupResponseModel.fromJson(response.data['data']);

        SharedPreferenceUtil.putString(AppConstant.signupResponsePre, jsonEncode(responseJson));
        SharedPreferenceUtil.putString(AppConstant.userTokenPre, responseJson.token);
        SharedPreferenceUtil.putInt(AppConstant.profileIdPre, response.data['data']['id']);

        return responseJson;
      } else if (response.statusCode == 412) {
        GlobalSnackBar.show(message: response.data['message'].toString());
        return null;
      }
      printLog(response.data);
    } catch (e) {
      // Provider.of<SignUpViewModel>(rootNavigatorKey.currentContext!,
      //     listen: false)
      //     .onStopLoader();
      // AppConstant.globalToast(  "Something wrong");
      debugPrint(e.toString());
    }
    return null;
  }



}
