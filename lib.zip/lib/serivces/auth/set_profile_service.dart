import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';

import '../../api/api_service.dart';
import '../../api/api_urls.dart';
import '../../models/auth/signup_model.dart';
import '../../utils/app_constants.dart';
import '../../utils/app_utils.dart';
import '../../utils/shared_preference_util.dart';
import '../../utils/snackbar.dart';

class SetProfileService {
  Future<SignupResponseModel?> getProfileData() async {
    try {
      final response = await ApiService().dio.get(
            ApiUrl.getUserProfileUrl,
            options: Options(
              headers: {
                'Content-Type': 'application/json',
                "vAuthorization":
                    'Bearer ${SharedPreferenceUtil.getString(AppConstant.userTokenPre)}'
              },
            ),
          );
      if (response.statusCode == 200) {
        var responseJson = SignupResponseModel.fromJson(response.data['data']);
        printLog(response.data['data']);
        return responseJson;
      } else if (response.statusCode == 412) {
        AppConstant.globalToast( response.data['message'].toString());
        return null;
      }
      printLog(response.data);
    } catch (e) {
      // Provider.of<SignUpViewModel>(rootNavigatorKey.currentContext!,
      //     listen: false)
      //     .onStopLoader();
      // AppConstant.globalToast("Something wrong");
      debugPrint(e.toString());
    }
    return null;
  }

  Future<SignupResponseModel?> setProfileData(FormData map) async {
    try {
      final response = await ApiService().dio.post(
            ApiUrl.completeUserProfileUrl,
            data: map,
            options: Options(
              headers: {
                'Content-Type': 'multipart/form-data',
                "vAuthorization":
                    'Bearer ${SharedPreferenceUtil.getString(AppConstant.userTokenPre)}'
              },
            ),
          );
      if (response.statusCode == 200) {
        debugPrint(response.data.toString());
        var responseJson = SignupResponseModel.fromJson(response.data['data']);
        SharedPreferenceUtil.putString(
            AppConstant.signupResponsePre, jsonEncode(responseJson));
        SharedPreferenceUtil.putInt(
            AppConstant.profileIdPre, response.data['data']['id']);
        SharedPreferenceUtil.putBool(AppConstant.isLoggedInPre, true);
        return responseJson;
      } else if (response.statusCode == 412) {
        GlobalSnackBar.show(message: response.data['message'].toString());
        return null;
      }
      printLog(response.data);
    } catch (e) {
      // Provider.of<SignUpViewModel>(rootNavigatorKey.currentContext!,
      //     listen: false)
      //     .onStopLoader();
      AppConstant.globalToast("Something wrong");
      debugPrint(e.toString());
    }
    return null;
  }


}
