import 'package:dio/dio.dart';
import 'package:flutter/material.dart';

import '../api/api_service.dart';
import '../api/api_urls.dart';
import '../api/dio_exception.dart';
import '../models/common/success_with_msg_model.dart';
import '../utils/app_utils.dart';

enum CheckAbilityTypeEnum { email, username }

class CommonServices {
  Future<SuccessWithMsg> checkAbility({
    required String strValue,
    required CheckAbilityTypeEnum abilityType,
    int? userId,
  }) async {
    String typeStr() {
      return abilityType == CheckAbilityTypeEnum.username
          ? "username"
          : "email";
    }

    Map<String, dynamic> map = {
      "user_id": userId,
      "type": typeStr(),
      "value": strValue
    };
    bool isSuccess = false;
    String? errorMsg;
    printLog(map);
    try {
      final response = await ApiService().dio.post(
            ApiUrl.checkAbilityUrl,
            data: map,
            options: Options(
              headers: {'Content-Type': 'application/json'},
            ),
          );
      if (response.statusCode == 200) {
        isSuccess = true;
        // GlobalSnackBar.show(message : response.data['message'].toString());
        // SharedPreferenceUtil.putInt(AppConstant.userIdPre, response.data['data']['id']);
      } else if (response.statusCode == 412) {
        errorMsg = response.data['message'].toString();
        // AppConstant.globalToast( response.data['message'].toString());

      }
      printLog(response.data);
    } on DioError catch (e) {
      DioException.fromDioError(e);
    } catch (e) {
      // Provider.of<SignUpViewModel>(rootNavigatorKey.currentContext!,
      //     listen: false)
      //     .onStopLoader();
      // AppConstant.globalToast(  "Something wrong");
      debugPrint(e.toString());
    }
    return SuccessWithMsg(isSuccess: isSuccess, msgText: errorMsg);
  }
}
