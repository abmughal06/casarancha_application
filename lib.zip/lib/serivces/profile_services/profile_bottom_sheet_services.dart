import 'dart:developer';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';

import '../../api/api_service.dart';
import '../../api/api_urls.dart';
import '../../utils/app_constants.dart';
import '../../utils/app_utils.dart';
import '../../utils/shared_preference_util.dart';

class ProfileBottomSheetServices {
  Future<bool> logOutApi() async {
    try {
      final response = await ApiService().dio.get(
            ApiUrl.logoutUSerUrl,
            options: Options(
              headers: {
                'Content-Type': 'application/json',
                "vAuthorization":
                    'Bearer ${SharedPreferenceUtil.getString(AppConstant.userTokenPre)}'
              },
            ),
          );
      log(response.data.toString());
      if (response.statusCode == 200) {
        AppConstant.globalToast(response.data['message'].toString());
        return true;
      } else if (response.statusCode == 412) {
        AppConstant.globalToast(response.data['message'].toString());
      }
      printLog(response.data);
    } catch (e) {
      AppConstant.globalToast("Something wrong");
      debugPrint(e.toString());
    }
    return false;
  }
}
