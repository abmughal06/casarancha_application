import 'dart:async';

import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:package_info_plus/package_info_plus.dart';

import '../api/api_service.dart';
import '../api/api_urls.dart';
import '../utils/app_constants.dart';
import '../utils/app_utils.dart';
import '../utils/shared_preference_util.dart';

class VersionDialog{
  bool isNeedToUpdateApp = false;
  Response? appVersionCheckRes;
  Future<Response?> versionCheckApi() async {
    final info = await PackageInfo.fromPlatform();
    printLog(info.version);
    Map<String, dynamic> mapVersionData = {
      "type": SharedPreferenceUtil.getString(AppConstant.deviceTypePre),
      "version":  info.version,
      "device_id": SharedPreferenceUtil.getString(AppConstant.deviceIdPre),
      "device_type": SharedPreferenceUtil.getString(AppConstant.deviceTypePre),
    };
    try {
      appVersionCheckRes = await ApiService().dio.post(
        ApiUrl.versionCheckUrl,
        data: mapVersionData,
        options: Options(
          headers: {
            'Content-Type': 'application/json',
          },
        ),
      );

      if (appVersionCheckRes!.statusCode == 412) {

        isNeedToUpdateApp = true;
      }
      printLog(appVersionCheckRes!.data);
    } catch (e) {
      AppConstant.globalToast("Something wrong");
      debugPrint(e.toString());
    }
    return appVersionCheckRes;
  }


}