import 'package:casarancha/models/media_details.dart';
import 'package:casarancha/screens/home/view_post_screen.dart';
import 'package:casarancha/widgets/PostCard/PostCardController.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:video_player/video_player.dart';

class VideoPlayerUrl extends StatefulWidget {
  const VideoPlayerUrl({
    Key? key,
    required this.mediaDetails,
    required this.pageIndex,
    this.videoPlayerController,
  }) : super(key: key);
  final MediaDetails mediaDetails;
  final int pageIndex;

  final VideoPlayerController? videoPlayerController;

  @override
  State<VideoPlayerUrl> createState() => _VideoPlayerUrlState();
}

class _VideoPlayerUrlState extends State<VideoPlayerUrl> {
  late VideoPlayerController videoPlayerController;
  bool isLoadingVideo = true;
  bool isPlayingVideo = false;
  @override
  void initState() {
    if (widget.videoPlayerController == null) {
      videoPlayerController = VideoPlayerController.network(
        widget.mediaDetails.link,
      );
    } else {
      videoPlayerController = widget.videoPlayerController!;
    }

    videoPlayerController.initialize().then((value) {
      setState(() {
        isLoadingVideo = false;
      });
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        VideoPlayer(
          videoPlayerController,
        ),
        Center(
          child: isLoadingVideo
              ? const CircularProgressIndicator.adaptive()
              : Container(),
        ),
        if (!isLoadingVideo)
          Align(
            alignment: Alignment.bottomLeft,
            child: IconButton(
              onPressed: () async {
                if (isPlayingVideo) {
                  await videoPlayerController.pause();
                  isPlayingVideo = false;
                } else {
                  await videoPlayerController.play();
                  isPlayingVideo = true;
                }
                setState(() {});
              },
              icon: Icon(
                isPlayingVideo
                    ? Icons.pause_circle_filled_rounded
                    : Icons.play_circle_fill_rounded,
              ),
            ),
          )
      ],
    );
  }
}
