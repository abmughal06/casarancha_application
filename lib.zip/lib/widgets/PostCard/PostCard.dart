import 'package:cached_network_image/cached_network_image.dart';
import 'package:timeago/timeago.dart' as timeago;

import 'package:casarancha/resources/color_resources.dart';
import 'package:casarancha/resources/image_resources.dart';
import 'package:casarancha/screens/home/view_post_screen.dart';
import 'package:casarancha/widgets/PostCard/PostCardController.dart';
import 'package:casarancha/widgets/common_widgets.dart';
import 'package:casarancha/widgets/music_player_url.dart';

import 'package:casarancha/widgets/text_widget.dart';
import 'package:casarancha/widgets/video_player_Url.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';

class PostCard extends StatelessWidget {
  const PostCard({
    Key? key,
    required this.postCardController,
  }) : super(key: key);

  final PostCardController postCardController;

  List<Widget> buildPostType() {
    final List<Widget> widgetList = [];
    for (var element in postCardController.post.value.mediaData) {
      int pageindex = postCardController.post.value.mediaData.indexOf(element);
      switch (element.type) {
        case 'Qoute':
          widgetList.add(
            InkWell(
              onTap: () => goToViewPostCardScreen(pageindex),
              child: AspectRatio(
                aspectRatio: 16 / 9,
                child: Center(
                  child: Padding(
                    padding: EdgeInsets.symmetric(horizontal: 10.w),
                    child: FittedBox(
                      child: Text(
                        element.link,
                        style: const TextStyle(
                          fontSize: 24,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          );
          break;
        case 'Photo':
          widgetList.add(InkWell(
            onTap: () => goToViewPostCardScreen(pageindex),
            child: AspectRatio(
              aspectRatio: 16 / 9,
              child: Center(
                  child: CachedNetworkImage(
                imageUrl: element.link,
                placeholder: (context, url) => shimmerImg(),
                errorWidget: (context, url, error) => Center(
                  child: Text(
                    error.toString(),
                  ),
                ),
              )),
            ),
          ));
          break;
        case 'Video':
          widgetList.add(InkWell(
            onTap: () => goToViewPostCardScreen(pageindex),
            child: VideoPlayerUrl(
              mediaDetails: element,
              pageIndex: pageindex,
            ),
          ));
          break;
        case 'Music':
          widgetList.add(MusicPlayerUrl(
            musicDetails: element,
            ontap: () => goToViewPostCardScreen(pageindex),
          ));
          break;
        default:
          widgetList.add(Container());
      }
    }
    return widgetList;
  }

  void goToViewPostCardScreen(int pageIndex) => Get.to(
        () => ViewPostScreen(
          postCardController: postCardController,
          pageIndex: pageIndex,
          widgetList: buildPostType(),
        ),
      );

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(
        vertical: 10.w,
        horizontal: 20.w,
      ),
      width: double.infinity,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10.r),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.8),
            blurRadius: 2.0,
            offset: const Offset(
              0,
              2,
            ),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 10.w),
            child: PostCreatorTile(postCardController: postCardController),
          ),
          AspectRatio(
            aspectRatio: 16 / 9,
            child: PageView(
              children: buildPostType(),
            ),
          ),

          heightBox(5.h),

          // postType == PostType.quote
          //     ? Padding(
          //         padding: EdgeInsets.only(left: 4.w, right: 13.w),
          //         child: GestureDetector(
          //           onTap: onTapPost,
          //           child: SizedBox(
          //             // height: 108.h,
          //             child: TextWidget(
          //               text: textQuotaPost ?? "",
          //               color: color221,
          //               fontWeight: FontWeight.w500,
          //               fontSize: 13.sp,
          //             ),
          //           ),
          //         ),
          //       )
          //     : ClipRRect(
          //         borderRadius: BorderRadius.circular(8.0),
          //         child: postType == PostType.music
          //             ? CachedNetworkImage(
          //                 imageUrl: imgUrlPost,
          //                 imageBuilder: (context, imageProvider) => SizedBox(
          //                   height: 160.h,
          //                   child: Stack(
          //                     children: [
          //                       GestureDetector(
          //                         onTap: onTapPost,
          //                         child: Container(
          //                           height: 160.h,
          //                           width: width,
          //                           decoration: BoxDecoration(
          //                             image: DecorationImage(
          //                               image: imageProvider,
          //                               fit: BoxFit.fill,
          //                             ),
          //                           ),
          //                         ),
          //                       ),
          //                       Align(
          //                         alignment: Alignment.bottomLeft,
          //                         child: Padding(
          //                           padding: EdgeInsets.symmetric(
          //                               horizontal: 15.w),
          //                           child: Column(
          //                             mainAxisSize: MainAxisSize.min,
          //                             crossAxisAlignment:
          //                                 CrossAxisAlignment.start,
          //                             children: [
          //                               TextWidget(
          //                                 text: songTitle,
          //                                 fontSize: 16.sp,
          //                                 fontWeight: FontWeight.w700,
          //                                 color: colorWhite,
          //                               ),
          //                               TextWidget(
          //                                 text: albumTitle,
          //                                 fontSize: 11.sp,
          //                                 fontWeight: FontWeight.w400,
          //                                 color: colorWhite,
          //                               ),
          //                               heightBox(20.h),
          //                               musicPlayer(
          //                                   screenSize: screenSize,
          //                                   musicUrl: musicUrl!,
          //                                   musicManager: musicManager),
          //                               heightBox(15.h),
          //                             ],
          //                           ),
          //                         ),
          //                       ),
          //                     ],
          //                   ),
          //                 ),
          //                 placeholder: (context, url) => shimmerImg(
          //                   height: 160.h,
          //                   width: width,
          //                 ),
          //                 errorWidget: (context, url, error) =>
          //                     const Icon(Icons.error),
          //               )
          //             : postType == PostType.video
          //                 ? FutureBuilder(
          //                     future: initializeVideoPlayerFuture,
          //                     builder: (context, snapshot) {
          //                       if (snapshot.connectionState ==
          //                           ConnectionState.done) {
          //                         // If the VideoPlayerController has finished initialization, use
          //                         // the data it provides to limit the aspect ratio of the video.
          //                         try {
          //                           return SizedBox(
          //                             height: 160.h,
          //                             width: width,
          //                             child: Stack(
          //                               children: [
          //                                 SizedBox(
          //                                   height: 160.h,
          //                                   width: width,
          //                                   child: AspectRatio(
          //                                     aspectRatio: videoController!
          //                                         .value.aspectRatio,
          //                                     // Use the VideoPlayer widget to display the video.
          //                                     child: VideoPlayer(
          //                                         videoController),
          //                                   ),
          //                                 ),
          //                                 Align(
          //                                     alignment: Alignment.center,
          //                                     child: svgImgButton(
          //                                         svgIcon: videoController
          //                                                 .value.isPlaying
          //                                             ? icVideoPlayBtn
          //                                             : icVideoPauseBtn,
          //                                         onTap: () {
          //                                           if (videoController
          //                                               .value.isPlaying) {
          //                                             videoController.pause();
          //                                           } else {
          //                                             // If the video is paused, play it.
          //                                             videoController.play();
          //                                           }
          //                                           viewModel!.onTapNotify();
          //                                         })),
          //                                 Align(
          //                                   alignment: Alignment.topRight,
          //                                   child: Padding(
          //                                     padding:
          //                                         const EdgeInsets.all(8.0),
          //                                     child: ValueListenableBuilder(
          //                                       valueListenable:
          //                                           videoController,
          //                                       builder: (context,
          //                                           VideoPlayerValue value,
          //                                           child) {
          //                                         //Do Something with the value.
          //                                         return TextWidget(
          //                                             text:
          //                                                 "${value.position.inMinutes < 9 ? "0" + value.position.inMinutes.toString() : value.position.inMinutes.toString()}"
          //                                                 ":"
          //                                                 "${value.position.inSeconds < 9 ? "0" + value.position.inSeconds.toString() : value.position.inSeconds.toString()}",
          //                                             color: colorWhite,
          //                                             fontSize: 11.sp,
          //                                             fontWeight:
          //                                                 FontWeight.w500,
          //                                             shadow: [
          //                                               Shadow(
          //                                                 offset:
          //                                                     const Offset(
          //                                                         0, 3),
          //                                                 blurRadius: 3.0,
          //                                                 color: colorBlack
          //                                                     .withOpacity(
          //                                                         0.31),
          //                                               ),
          //                                             ]);
          //                                       },
          //                                     ),
          //                                   ),
          //                                 ),
          //                                 Align(
          //                                     alignment:
          //                                         Alignment.bottomRight,
          //                                     child: Padding(
          //                                       padding:
          //                                           const EdgeInsets.all(8.0),
          //                                       child: svgImgButton(
          //                                           svgIcon: viewModel!
          //                                                   .isOnSoundVideo
          //                                               ? icVideoSoundOff
          //                                               : icVideoSoundOn,
          //                                           onTap: () {
          //                                             viewModel!.isOnSoundVideo ==
          //                                                     false
          //                                                 ? videoController
          //                                                     .setVolume(0.0)
          //                                                 : videoController
          //                                                     .setVolume(1.0);
          //                                             viewModel!
          //                                                 .onTapNotify();
          //                                           }),
          //                                     )),
          //                               ],
          //                             ),
          //                           );
          //                         } catch (e, s) {
          //                           printLog(s);
          //                           return SizedBox(
          //                             height: 160.h,
          //                             width: width,
          //                           );
          //                         }
          //                       } else {
          //                         return const Center(
          //                           child: CircularProgressIndicator(),
          //                         );
          //                       }
          //                     },
          //                   )
          //                 : CachedNetworkImage(
          //                     imageUrl: imgUrlPost,
          //                     imageBuilder: (context, imageProvider) =>
          //                         Container(
          //                       height: 160.h,
          //                       width: width,
          //                       decoration: BoxDecoration(
          //                         image: DecorationImage(
          //                           image: imageProvider,
          //                           fit: BoxFit.fill,
          //                         ),
          //                       ),
          //                     ),
          //                     placeholder: (context, url) => shimmerImg(
          //                       height: 160.h,
          //                       width: width,
          //                     ),
          //                     errorWidget: (context, url, error) =>
          //                         const Icon(Icons.error),
          //                   ),
          //       ),
          PostRowButtons(
            postCardController: postCardController,
          ),
          // Row(
          //   children: [
          //     IconButton(
          //       onPressed: postCardController.likeDisLikePost,
          //       icon: Obx(
          //         () => SvgPicture.asset(
          //           postCardController.isLiked.value ? icLikeRed : icLikeWhite,
          //         ),
          //       ),
          //     ),
          //     widthBox(5.w),
          //     Obx(
          //       () => TextWidget(
          //         text: '${postCardController.post.value.likesIds.length}',
          //         color: color221,
          //         fontWeight: FontWeight.w400,
          //         fontSize: 12.sp,
          //       ),
          //     ),
          //     widthBox(10.w),
          //     IconButton(
          //       onPressed: goToViewPostCardScreen,
          //       icon: SvgPicture.asset(
          //         icCommentPost,
          //       ),
          //     ),
          //     widthBox(5.w),
          //     Obx(
          //       () => TextWidget(
          //         text: '${postCardController.post.value.commentIds.length}',
          //         color: color221,
          //         fontWeight: FontWeight.w400,
          //         fontSize: 12.sp,
          //       ),
          //     ),
          //     widthBox(10.w),
          //     IconButton(
          //       onPressed: () {},
          //       icon: SvgPicture.asset(
          //         icSharePost,
          //       ),
          //     ),
          //     // likeCmtShareWidget(
          //     //     isLikedPost: viewModel.isLikedPostList[index],
          //     //     onTapLike: () {
          //     //       viewModel.onTapLikePost(index: index);
          //     //     },
          //     //     likeCount: likeCount ?? "0",
          //     //     commentCount: commentCount ?? "0",
          //     //     onTapSharePost: onTapSharePost),
          //     const Spacer(),
          //     IconButton(
          //       onPressed: () {},
          //       icon: SvgPicture.asset(
          //         icBookMarkReg,
          //         //icSavedPost
          //       ),
          //     ),
          //     // svgImgButton(
          //     //     svgIcon: viewModel.isSavedPost[index]
          //     //         ? icSavedPost
          //     //         : icBookMarkReg,
          //     //     width: 20,
          //     //     height: 20,
          //     //     onTap: () {
          //     //       viewModel.onTapSavePost(index: index);
          //     //     }),
          //   ],
          // ),

          Padding(
            padding: EdgeInsets.only(
              bottom: 10.w,
              right: 10.w,
              left: 10.w,
            ),
            child: TextWidget(
              text: postCardController.post.value.description,
              color: color55F,
              fontWeight: FontWeight.w400,
              fontSize: 13.sp,
            ),
          )
        ],
      ),
    );
  }
}

class PostCreatorTile extends StatelessWidget {
  const PostCreatorTile({
    Key? key,
    required this.postCardController,
  }) : super(key: key);

  final PostCardController postCardController;

  @override
  Widget build(BuildContext context) {
    final dateText =
        timeago.format(DateTime.parse(postCardController.post.value.createdAt));
    return ListTile(
      onTap: () => postCardController.gotoAppUserScreen(
        postCardController.post.value.creatorId,
      ),
      contentPadding: EdgeInsets.zero,
      title: Row(
        children: [
          Text(postCardController.post.value.creatorDetails.name),
          widthBox(5.w),
          if (postCardController.post.value.creatorDetails.isVerified)
            SvgPicture.asset(icVerifyBadge),
        ],
      ),
      subtitle: TextWidget(
        text: '$dateText at ${postCardController.post.value.locationName}',
        color: color55F,
        fontSize: 11.sp,
        textOverflow: TextOverflow.ellipsis,
      ),
      leading: CachedNetworkImage(
        imageUrl: postCardController.post.value.creatorDetails.imageUrl,
        imageBuilder: (context, imageProvider) => CircleAvatar(
          radius: 25.r,
          backgroundImage: imageProvider,
        ),
        placeholder: (context, url) => shimmerImg(
            child: CircleAvatar(
          radius: 25.r,
        )),
        errorWidget: (context, url, error) => CircleAvatar(
          radius: 25.r,
          backgroundColor: Colors.white,
          child: const Center(
            child: Icon(
              Icons.error,
            ),
          ),
        ),
      ),
      // trailing: IconButton(
      //     onPressed: () {},
      //     icon: SvgPicture.asset(
      //       icCardMenu,
      //     )),
    );
  }
}

class PostRowButtons extends StatelessWidget {
  const PostRowButtons({
    Key? key,
    required this.postCardController,
  }) : super(key: key);

  final PostCardController postCardController;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        IconButton(
          visualDensity: VisualDensity.compact,
          onPressed: postCardController.likeDisLikePost,
          icon: Obx(
            () => SvgPicture.asset(
              postCardController.isLiked.value ? icLikeRed : icLikeWhite,
            ),
          ),
        ),
        widthBox(2.5.w),
        Obx(
          () => TextWidget(
            text: '${postCardController.post.value.likesIds.length}',
            color: color221,
            fontWeight: FontWeight.w400,
            fontSize: 12.sp,
          ),
        ),
        widthBox(10.w),
        IconButton(
          visualDensity: VisualDensity.compact,
          onPressed: null,
          icon: SvgPicture.asset(
            icCommentPost,
          ),
        ),
        widthBox(2.5.w),
        Obx(
          () => TextWidget(
            text: '${postCardController.post.value.commentIds.length}',
            color: color221,
            fontWeight: FontWeight.w400,
            fontSize: 12.sp,
          ),
        ),
        widthBox(10.w),
        IconButton(
          visualDensity: VisualDensity.compact,
          onPressed: () {},
          icon: SvgPicture.asset(
            icSharePost,
          ),
        ),
        const Spacer(),
        IconButton(
          visualDensity: VisualDensity.compact,
          onPressed: postCardController.savePost,
          icon: Obx(() => SvgPicture.asset(
                postCardController.isSaved.value ? icSavedPost : icBookMarkReg,
              )),
        ),
      ],
    );
  }
}
