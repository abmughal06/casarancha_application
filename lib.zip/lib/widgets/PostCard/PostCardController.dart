import 'package:casarancha/models/comment_model.dart';
import 'package:casarancha/models/post_creator_details.dart';
import 'package:casarancha/models/post_model.dart';
import 'package:casarancha/screens/profile/ProfileScreen/profile_screen_controller.dart';
import 'package:casarancha/screens/profile/app_user_screen.dart';
import 'package:casarancha/utils/snackbar.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class PostCardController extends GetxController {
  PostCardController({required this.postdata});
  final PostModel postdata;

  late ProfileScreenController profileScreenController;
  late TextEditingController commentController;

  String currentUserId = '';
  late var isLiked = false.obs;
  late var isSaved = false.obs;
  late DocumentReference<Map<String, dynamic>> postRef;

  //Obserables
  var post = PostModel(
          id: '',
          creatorId: '',
          creatorDetails: CreatorDetails(
            name: '',
            imageUrl: '',
            isVerified: false,
          ),
          createdAt: '',
          description: '',
          locationName: '',
          shareLink: '')
      .obs;

  //Methods

  Future<void> likeDisLikePost() async {
    try {
      if (isLiked.value) {
        postRef.update({
          'likesIds': FieldValue.arrayRemove([currentUserId])
        });
        post.update((val) {
          val!.likesIds.remove(currentUserId);
        });
      } else {
        postRef.update({
          'likesIds': FieldValue.arrayUnion([currentUserId])
        });
        post.update((val) {
          val!.likesIds.add(currentUserId);
        });
      }
      isLiked.value = !isLiked.value;
    } catch (e) {
      GlobalSnackBar.show(message: e.toString());
    }
  }

  Future<void> commentOnPost() async {
    final commentText = commentController.text.trim();
    if (commentText.isEmpty) {
      GlobalSnackBar.show(message: 'Please write a comment');
      return;
    }
    final commentRef = postRef.collection('comments').doc();
    final commentId = commentRef.id;
    final comment = Comment(
        id: commentId,
        creatorId: currentUserId,
        creatorDetails: CreatorDetails(
          name: profileScreenController.user.value.name,
          imageUrl: profileScreenController.user.value.imageStr,
          isVerified: profileScreenController.user.value.isVerified,
        ),
        createdAt: DateTime.now().toIso8601String(),
        message: commentText);
    try {
      postRef.update({
        'commentIds': FieldValue.arrayUnion([commentId])
      });
      commentRef.set(comment.toMap());
      commentController.clear();
      post.update((val) {
        val!.commentIds.add(commentId);
      });
    } catch (e) {
      GlobalSnackBar.show(message: e.toString());
    }
  }

  Future<void> savePost() async {
    try {
      final userRef =
          FirebaseFirestore.instance.collection('users').doc(currentUserId);
      if (isSaved.value) {
        userRef.update({
          'savedPostsIds': FieldValue.arrayRemove([post.value.id])
        });
        profileScreenController.user.update((val) {
          val!.savedPostsIds.remove(currentUserId);
        });
      } else {
        userRef.update({
          'savedPostsIds': FieldValue.arrayUnion([post.value.id])
        });
        profileScreenController.user.update((val) {
          val!.savedPostsIds.add(currentUserId);
        });
      }
      isSaved.value = !isSaved.value;
    } catch (e) {
      GlobalSnackBar.show(message: e.toString());
    }
  }

  void gotoAppUserScreen(String appUserId) {
    Get.to(
      () => AppUserScreen(
        appUserId: appUserId,
        currentUserId: currentUserId,
      ),
    );
  }

  //OverRides
  @override
  void onInit() {
    profileScreenController = Get.find<ProfileScreenController>();
    commentController = TextEditingController();

    currentUserId = profileScreenController.user.value.id;
    post.value = postdata;

    postRef = FirebaseFirestore.instance.collection('posts').doc(post.value.id);

    isLiked.value = post.value.likesIds.contains(currentUserId);

    isSaved.value = profileScreenController.user.value.savedPostsIds
        .contains(post.value.id);

    super.onInit();
  }

  @override
  void dispose() {
    commentController.dispose();
    super.dispose();
  }
}
